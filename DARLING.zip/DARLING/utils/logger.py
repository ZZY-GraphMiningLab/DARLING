import os
import time
import logging



def star_formatter(msg, short=False):
    if short:
        return '*'* 6 + ' ' + msg + ' ' + '*'* 6 + '\n'
    else:
        return '*'* 36 + ' ' + msg + ' ' + '*'* 36 + '\n'*2

def get_separator():
    return '*'* 50 + '\n'*5



class MyLogger(object):
    level_relations = {
        'debug' : logging.DEBUG,
        'info' : logging.INFO,
        'warning' : logging.WARNING,
        'error' : logging.ERROR,
        'critical' : logging.CRITICAL
    }

    def __init__(self,
                 log_dir='logs/', exp_id=None, trial_id=None,
                 model_name='model', task_name='NCLS', params=None,
                 level='debug', 
                 fmt='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'):

        self.log_dir = log_dir
        self.exp_id = exp_id
        self.trial_id = trial_id

        self.start_time = time.strftime("%m-%d-%Y-%H-%M-%S", time.localtime())

        self.filename = os.path.join(self.log_dir, 
                f"{model_name}_{params['dataset']}_{task_name}_{self.start_time}_Exp_{self.exp_id}_Trial_{self.trial_id}.log")

        self.logger = logging.getLogger(self.filename)
        self.logger.setLevel(self.level_relations.get(level))

        format_str = logging.Formatter(fmt)
        sh = logging.StreamHandler()
        sh.setFormatter(format_str)

        fh = logging.FileHandler(filename=self.filename,
                                  mode='a',
                                  encoding='utf-8')
        fh.setFormatter(format_str)

        self.logger.addHandler(sh)
        self.logger.addHandler(fh)


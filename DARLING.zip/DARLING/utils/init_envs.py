import os





def set_visible_gpus(gpus):
    os.environ["CUDA_VISIBLE_DEVICES"] = gpus



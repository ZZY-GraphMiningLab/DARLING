import torch

from utils.constants import VERY_SMALL_NUMBER




def safe_divide(a, b):
    return torch.where(b > VERY_SMALL_NUMBER, a / b, 
                                torch.tensor(0.0, dtype=a.dtype, device=a.device))


def floor_to_nonzero(a):
    return torch.where(a > VERY_SMALL_NUMBER, a, 
                        torch.tensor(VERY_SMALL_NUMBER, dtype=a.dtype, device=a.device))


def randint_list(low, high=None, size=None, device='cuda'):
    """
    Credit: https://github.com/pytorch/pytorch/issues/89438#issuecomment-1862363360
    """

    if high is None:
        high = low
        low = 0

    if size is None:
        size = low.shape if isinstance(low, torch.Tensor) else high.shape

    return torch.randint(2**63 - 1, size=size, device=device) % (high - low) + low


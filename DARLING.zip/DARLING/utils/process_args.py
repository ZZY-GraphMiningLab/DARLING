import torch

def process_args(params, warning_str=""):

    warning_str = ""

    if isinstance(params['device'], int):
        if params['device'] >= 0:
            params['device'] = torch.device('cuda')
        else:
            params['device'] = torch.device('cpu')

    # parse the parameters
    if params['feat_norm'].lower() == 'true':
        params['feat_norm'] = True
    else:
        params['feat_norm'] = False

    return params, warning_str
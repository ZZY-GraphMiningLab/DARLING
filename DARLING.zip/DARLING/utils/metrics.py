import numpy as np
from sklearn.metrics import roc_auc_score



def accuracy(labels, pred, use_mat=True) -> float:
    if use_mat:
        return np.sum(pred.argmax(1)==labels)/len(labels)
    else:
        return np.sum(pred==labels)/len(labels)

def calculate_cls_metrics(labels, logp):
    from scipy.special import softmax

    if logp.shape[1] == 2:
        probs = softmax(logp, axis=-1)

        return roc_auc_score(labels, probs[:, 1])
    else:
        return accuracy(labels, logp)

def calculate_pl_metrics(labels, pred, class_num):
    """
    """

    if class_num == 2:
        return roc_auc_score(labels, pred)
    else:
        return accuracy(labels, pred, use_mat=False)


if __name__ == '__main__':

    from sklearn.datasets import load_breast_cancer
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score

    X, y = load_breast_cancer(return_X_y=True)
    clf = LogisticRegression(solver="liblinear", random_state=0).fit(X, y)

    ttt = clf.predict_proba(X)

    roc_auc_score(y, clf.predict_proba(X)[:, 1])
    roc_auc_score(y, clf.decision_function(X))


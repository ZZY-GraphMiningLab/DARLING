import torch
import torch.nn.functional as F
from torch_geometric.utils import add_self_loops, add_remaining_self_loops

import numpy as np
from torch_geometric.typing import OptTensor
from torch_sparse import SparseTensor, index_select




def sparse_dropout(x: torch.Tensor, p: float):
    """
    Credits: 
        https://github.com/pytorch/pytorch/issues/35798#issuecomment-1194972269
        https://discuss.pytorch.org/t/implementation-of-dropout-for-sparse-input/47720/2?u=april211
    """
    x = x.coalesce()
    mask = torch.rand(x.indices().size(1), device=x.device) >= p

    return torch.sparse_coo_tensor(x.indices()[:, mask].detach(), 
                                   x.values()[mask].detach(), 
                                   dtype=x.dtype, 
                                   size=x.size(), device=x.device)


def sym_norm_sp_tensor_tractable(adj: torch.Tensor, add_loop=True, device='cuda'):
    """
    Borrowed from OpenGSL & got the efficiency issue fixed.

    This implementation is compatible with directed graphs.
    """

    if add_loop:                                        # *** fix
        # adj = add_self_loops_torch_sp(adj, device=device)
        adj = add_remaining_self_loops_torch_sp(adj, device=device)

    if not adj.is_coalesced():
        adj = adj.coalesce()                            # *** fix

    # inv_sqrt_degree = 1. / (torch.sqrt(torch.sparse.sum(adj, dim=1).to_dense()) + 1e-12)
    # D_value = inv_sqrt_degree[adj.indices()[0]] * inv_sqrt_degree[adj.indices()[1]]
    # new_values = adj.values() * D_value

    indices = adj.indices()
    
    in_degree = torch.sparse.sum(adj, dim=1).to_dense()
    out_degree = torch.sparse.sum(adj, dim=0).to_dense()

    inv_sqrt_in = 1.0 / (torch.sqrt(in_degree) + 1e-12)
    inv_sqrt_out = 1.0 / (torch.sqrt(out_degree) + 1e-12)

    norm_coef = inv_sqrt_in[indices[0]] * inv_sqrt_out[indices[1]]

    new_values = adj.values() * norm_coef

    return torch.sparse_coo_tensor(adj.indices().detach().clone(), 
                    new_values, dtype=torch.float32, size=adj.size(), device=device)


def sym_norm_dense_tensor(adj: torch.Tensor):
    """
    This implementation is compatible with directed graphs.
    """

    # inv_sqrt_degree = 1. / (torch.sqrt(torch.sum(adj, dim=1)) + 1e-12)
    # D_value = torch.einsum('i,j->ij', inv_sqrt_degree, inv_sqrt_degree)
    # new_values = adj * D_value

    in_degree = torch.sum(adj, dim=1)
    out_degree = torch.sum(adj, dim=0)

    inv_sqrt_in = 1.0 / (torch.sqrt(in_degree) + 1e-12)
    inv_sqrt_out = 1.0 / (torch.sqrt(out_degree) + 1e-12)

    norm_matrix = torch.einsum('i,j->ij', inv_sqrt_in, inv_sqrt_out)

    return adj * norm_matrix


def row_norm_sp(adj: torch.Tensor, add_loop=True, device='cuda'):       # *** fix
    """
    Borrowed from OpenGSL & got the invalid variable name fixed.
    """

    if add_loop:                                        # *** fix
        # adj = add_self_loops_torch_sp(adj, device=device)
        adj = add_remaining_self_loops_torch_sp(adj, device=device)

    if not adj.is_coalesced():
        adj = adj.coalesce()                            # *** fix

    inv_sqrt_degree = 1. / (torch.sparse.sum(adj, dim=1).to_dense() + 1e-12)        # *** fix: to_dense()
    D_value = inv_sqrt_degree[adj.indices()[0]]
    new_values = adj.values() * D_value
    return torch.sparse_coo_tensor(adj.indices().detach().clone(), 
                    new_values, dtype=torch.float32, size=adj.size(), device=device)


def col_norm_sp(adj: torch.Tensor, add_loop=True, device='cuda'):       # *** fix
    """
    Borrowed from OpenGSL & got the invalid variable name fixed.
    """

    if add_loop:                                        # *** fix
        # adj = add_self_loops_torch_sp(adj, device=device)
        adj = add_remaining_self_loops_torch_sp(adj, device=device)

    if not adj.is_coalesced():
        adj = adj.coalesce()                            # *** fix

    inv_sqrt_degree = 1. / (torch.sparse.sum(adj, dim=0).to_dense() + 1e-12)        # *** fix: to_dense()
    D_value = inv_sqrt_degree[adj.indices()[1]]
    new_values = adj.values() * D_value
    return torch.sparse_coo_tensor(adj.indices().detach().clone(), 
                    new_values, dtype=torch.float32, size=adj.size(), device=device)


def epsilon_sparsify_sp(adj: torch.Tensor, epsilon=0.1, device='cuda'):
    """
    """

    # adj = adj.coalesce()
    mask = adj.values() > epsilon
    indices = adj.indices()[:, mask]
    values = adj.values()[mask]

    return torch.sparse_coo_tensor(indices.detach(), 
                    values, dtype=torch.float32, size=adj.size(), device=device)


def epsilon_sparsify_dense(attention, epsilon, markoff_value=0.0):
    """
    Borrowed from PROSE: `build_epsilon_neighbourhood`.
    """

    mask = (attention > epsilon).detach().float()
    # weighted_adjacency_matrix = attention * mask + markoff_value * (1 - mask)
    weighted_adjacency_matrix = attention * mask
    return weighted_adjacency_matrix


def global_topk_sparsify_sp(adj: torch.Tensor, k=10, add_self_loop=True, device='cuda'):
    """
    """

    if not adj.is_coalesced():
        adj = adj.coalesce()

    _, indices = adj.values().topk(k, largest=True)
    del _

    # mask = torch.empty(adj.values().size(), dtype=torch.bool, device=device).fill_(False)
    # mask[indices] = True

    indices = adj.indices()[:, indices]
    # values = adj.values()[mask]
    values = torch.ones(indices.size(1), dtype=torch.float32, device=device)        # unnormamlized

    res = torch.sparse_coo_tensor(indices.detach(), 
                    values.detach(), dtype=torch.float32, size=adj.size(), device=device)

    if add_self_loop:
        res = add_remaining_self_loops_torch_sp(res, device=device)

    return res.coalesce()

def row_norm_dense(mx):
    """
    Borrowed from OpenGSL. 

    fix: generation of NaN values.
    """

    r_sum = mx.sum(1)
    r_sum = torch.where(r_sum <= 0.0, torch.tensor([1.0], device=r_sum.device, dtype=torch.float32), r_sum)
    r_inv = r_sum.pow(-1).flatten()
    del r_sum

    mx = torch.einsum('i,ij->ij', r_inv, mx)

    return mx


def add_self_loops_torch_sp(adj: torch.Tensor, device='cuda'):

    adj = adj.to(device)
    if not adj.is_coalesced():
        adj = adj.coalesce()
    indices = adj.indices()
    values = adj.values()

    new_indices, new_values = add_self_loops(edge_index=indices, edge_attr=values, 
                                             fill_value=1.0, num_nodes=adj.shape[0])
    adj = torch.sparse_coo_tensor(new_indices, new_values, 
                    dtype=torch.float32, size=adj.size(), device=device)

    return adj


def add_remaining_self_loops_torch_sp(adj: torch.Tensor, device='cuda'):

    adj = adj.to(device)
    if not adj.is_coalesced():
        adj = adj.coalesce()
    indices = adj.indices()
    values = adj.values()

    new_indices, new_values = add_remaining_self_loops(edge_index=indices, edge_attr=values, 
                                                     fill_value=1.0, num_nodes=adj.shape[0])
    adj = torch.sparse_coo_tensor(new_indices.detach(), new_values.detach(), 
                           dtype=torch.float32, size=adj.size(), device=device)

    return adj


def unnorm_adj_sp(adj_weighted: torch.Tensor, add_self_loop=True, device='cuda'):

    assert adj_weighted.is_sparse, "adj_normalized should be a sparse torch.Tensor!"

    # fill the non-zero entries with 1
    if not adj_weighted.is_coalesced():
        adj_weighted = adj_weighted.coalesce()
    new_values = torch.ones_like(adj_weighted.values(), dtype=torch.float32, device=device)

    res = torch.sparse_coo_tensor(adj_weighted.indices().detach().clone(), 
                    new_values, dtype=torch.float32, size=adj_weighted.size(), device=device)

    if add_self_loop:
        res = add_remaining_self_loops_torch_sp(res, device=device)

    return res


def compute_anchor_adj_normed_dense(node_anchor_adj, anchor_mask=None):
    """
    Borrowed from PROSE.
    """

    anchor_node_adj = node_anchor_adj.transpose(-1, -2)
    anchor_norm = torch.clamp(anchor_node_adj.sum(dim=-2), min=1e-12) ** -1     # size: (n,)
    node_norm = torch.clamp(node_anchor_adj.sum(dim=-2), min=1e-12) ** -1       # size: (s,)
    # anchor_adj = torch.matmul(anchor_node_adj, torch.matmul(torch.diag(anchor_norm), node_anchor_adj))
    # anchor_adj = torch.matmul(anchor_node_adj, anchor_norm.unsqueeze(-1) * node_anchor_adj)
    anchor_adj = torch.matmul(
        node_norm.unsqueeze(-1) * anchor_node_adj, 
        anchor_norm.unsqueeze(-1) * node_anchor_adj
    )

    # markoff_value = 0
    # if anchor_mask is not None:
    #     anchor_adj = anchor_adj.masked_fill_(1 - anchor_mask.byte().unsqueeze(-1), markoff_value)
    #     anchor_adj = anchor_adj.masked_fill_(1 - anchor_mask.byte().unsqueeze(-2), markoff_value)

    return anchor_adj 


def compute_anchor_adj_unnormed_dense(node_anchor_adj, anchor_mask=None):
    """
    Borrowed from PROSE.
    """

    anchor_node_adj = node_anchor_adj.transpose(-1, -2)
    anchor_norm = torch.clamp(anchor_node_adj.sum(dim=-2), min=1e-12) ** -1     # size: (n,)
    # anchor_adj = torch.matmul(anchor_node_adj, torch.matmul(torch.diag(anchor_norm), node_anchor_adj))
    anchor_adj = torch.matmul(anchor_node_adj, anchor_norm.unsqueeze(-1) * node_anchor_adj)

    # markoff_value = 0
    # if anchor_mask is not None:
    #     anchor_adj = anchor_adj.masked_fill_(1 - anchor_mask.byte().unsqueeze(-1), markoff_value)
    #     anchor_adj = anchor_adj.masked_fill_(1 - anchor_mask.byte().unsqueeze(-2), markoff_value)

    return anchor_adj  


def add_graph_degree_loss(out_adj, degree_weight=0.03):
    """
    Credit: IDGL.
    """

    # Graph regularization
    graph_loss = 0
    # L = torch.diagflat(torch.sum(out_adj, -1)) - out_adj
    # graph_loss += self.config['smoothness_ratio'] * torch.trace(torch.mm(features.transpose(-1, -2), torch.mm(L, features))) / int(np.prod(out_adj.shape))
    ones_vec = torch.ones(out_adj.size(-1)).cuda()
    graph_loss = - degree_weight * torch.mm(ones_vec.unsqueeze(0), torch.log(torch.mm(out_adj, ones_vec.unsqueeze(-1)) + 1e-12)).squeeze() / out_adj.shape[-1]
    return graph_loss


def add_graph_smooth_loss(out_adj: torch.Tensor, features: torch.Tensor, smooth_weight: int=0.03):
    """
    Credit: IDGL.
    """

    L = torch.diagflat(torch.sum(out_adj, -1)) - out_adj            # laplacian matrix
    loss = smooth_weight * torch.trace(torch.mm(features.transpose(-1, -2), 
                                       torch.mm(L, features))) / int(np.prod(out_adj.shape))
    return loss


def add_graph_mse_loss(pred: torch.Tensor, label: torch.Tensor, loss_weight: int=0.03):

    loss = loss_weight * torch.mean(torch.pow(pred - label, 2.0))

    return loss


def compute_node_adj_sp(node_anchor_adj):
    """
    """

    node_norm = col_norm_sp(node_anchor_adj, 
            add_loop=False, device=node_anchor_adj.device)
    anchor_norm = row_norm_sp(node_anchor_adj, 
            add_loop=False, device=node_anchor_adj.device)

    return torch.sparse.mm(anchor_norm, node_norm.transpose(-1, -2))

    # node_norm = col_norm_sp(node_anchor_adj, 
    #         add_loop=False, device=node_anchor_adj.device)

    # return torch.sparse.mm(node_anchor_adj, node_norm.transpose(-1, -2))


def compute_node_adj_dense(R):
    """
    `R` is a 2D dense tensor.
    """

    node_norm = R / torch.clamp(torch.sum(R, dim=-2, keepdim=True), min=1e-12)
    anchor_norm = R / torch.clamp(torch.sum(R, dim=-1, keepdim=True), min=1e-12)

    # mp_anchor = torch.matmul(anchor_norm, node_norm.transpose(-1, -2))
    mp_anchor = torch.einsum('ik,jk->ij', anchor_norm, node_norm)
    return mp_anchor


def compute_unnorm_node_adj_sp(node_anchor_adj: torch.Tensor, use_truncation=False, add_self_loop=True):
    """
    `node_anchor_adj` is a sparse tensor.

    `use_truncation`: clip the values to 1.0.
    """

    node_norm = col_norm_sp(node_anchor_adj, 
            add_loop=False, device=node_anchor_adj.device)

    unnorm_node_adj_sp = torch.sparse.mm(node_anchor_adj, node_norm.transpose(-1, -2))

    if add_self_loop:
        unnorm_node_adj_sp = add_remaining_self_loops_torch_sp(unnorm_node_adj_sp, 
                                                               device=node_anchor_adj.device)

    if not use_truncation:
        return unnorm_node_adj_sp
    else:
        print("Truncation is applied!")
        unnorm_node_adj_sp = unnorm_node_adj_sp.coalesce()
        values = unnorm_node_adj_sp.values().detach()
        values[values > 1.0] = 1.0
        return torch.sparse_coo_tensor(unnorm_node_adj_sp.indices().detach(), values.detach(), 
                size=unnorm_node_adj_sp.size(), dtype=torch.float32, device=node_anchor_adj.device)
    


def get_feat_mask(features, mask_rate, device='cuda'):
    """
    Borrowed from PROSE.
    """

    feat_node = features.shape[1]
    mask = torch.zeros(features.shape)
    samples = np.random.choice(feat_node, size=int(feat_node * mask_rate), replace=False)
    mask[:, samples] = 1
    return mask.to(device), samples


def split_batch(init_list, batch_size):
    """
    Borrowed from PROSE.
    """

    groups = zip(*(iter(init_list),) * batch_size)
    end_list = [list(i) for i in groups]
    count = len(init_list) % batch_size
    end_list.append(init_list[-count:]) if count != 0 else end_list
    return end_list


"""
The code below is borrowed from `TriCL`.
"""

def drop_features_dim(x: torch.Tensor, p: float):
    """
    """
    drop_mask = torch.empty((x.size(1), ), dtype=torch.float32, device=x.device).uniform_(0, 1) < p
    x = x.clone()

    # https://github.com/pytorch/pytorch/issues/68525
    x[:, drop_mask] = torch.zeros(x.size(0), drop_mask.long().sum(), device=x.device, dtype=x.dtype)
    return x.detach()


def filter_incidence(row: torch.Tensor, col: torch.Tensor, hyperedge_attr: OptTensor, mask: torch.Tensor):
    return row[mask], col[mask], None if hyperedge_attr is None else hyperedge_attr[mask]


def drop_incidence(hyperedge_index: torch.Tensor, p: float = 0.2):
    """
    """
    if p == 0.0:
        return hyperedge_index

    # row, col = hyperedge_index
    # mask = torch.rand(row.size(0), device=hyperedge_index.device) >= p

    # row, col, _ = filter_incidence(row, col, None, mask)
    # hyperedge_index = torch.stack([row, col], dim=0)
    # return hyperedge_index

    mask = torch.rand(hyperedge_index.size(1), device=hyperedge_index.device) >= p

    return hyperedge_index[:, mask].detach()


def drop_hyperedges_index_dense(hyperedge_index: torch.Tensor, num_nodes: int, num_edges: int, p: float):
    if p == 0.0:
        return hyperedge_index

    drop_mask = torch.rand(num_edges, device=hyperedge_index.device) < p
    drop_idx = drop_mask.nonzero(as_tuple=True)[0]

    H = torch.sparse_coo_tensor(hyperedge_index, 
        hyperedge_index.new_ones((hyperedge_index.shape[1],)), (num_nodes, num_edges)).to_dense()
    H[:, drop_idx] = 0
    hyperedge_index = H.to_sparse().indices()

    return hyperedge_index


def drop_hyperedges_index_sp(hyperedge_index: torch.Tensor, num_nodes: int, num_edges: int, p: float):
    """
    """

    if p == 0.0:
        return hyperedge_index

    device = hyperedge_index.device

    keep_mask = torch.rand(num_edges, device=device) > p
    keep_idx = keep_mask.nonzero(as_tuple=True)[0]

    del keep_mask

    H = SparseTensor.from_edge_index(
                        edge_index=hyperedge_index.detach().clone(), 
                        edge_attr=None, 
                        sparse_sizes=(num_nodes, num_edges), 
                        is_sorted=False
                    ).to(device)

    H = index_select(H, 1, keep_idx).coalesce()

    hyperedge_index = torch.vstack([H.storage.row(), 
                                    H.storage.col()])

    return hyperedge_index.detach()


"""
The code below is borrowed from `HYPEBOY`.
"""

def drop_hyperedges_dict(hyperedge_dict, p, num_edge, device) :

    isolated_edges = {i : 0 for i in range(num_edge)}

    he_num_given = len(hyperedge_dict) - int(p * len(hyperedge_dict))
    # given_hes = []
    he_given = np.random.choice(a = list(hyperedge_dict.keys()), size = he_num_given, replace = False)
    he_given = {i : 0 for i in he_given}

    # HEDGEs = []
    EIDXs = []
    HEIDXs = []
    he_idx_new = 0
    # he_non_given = []
    for he in hyperedge_dict : 
        try : 
            he_given[he]
            for e in hyperedge_dict[he] : 
                try : 
                    del isolated_edges[e]
                except : 
                    None
            EIDXs.extend(hyperedge_dict[he])
            HEIDXs.extend([he_idx_new] * len(hyperedge_dict[he]))
            # given_hes.append(hyperedge_dict[he])
            he_idx_new += 1
        except : 
            # HEDGEs.append(hyperedge_dict[he])
            # he_non_given.append(he)
            None

    for e in isolated_edges : 
        EIDXs.append(e)
        HEIDXs.append(he_idx_new)
        he_idx_new += 1

    E = torch.tensor([EIDXs, HEIDXs]).to(device)

    return E, he_idx_new


def drop_hyperedges_tensor(hyperedge_index: torch.Tensor, num_edges: int, num_hyperedges: int, p: float) :
    """
    A wrapper of the function `drop_hyperedges_index`.
    """

    hyperedge_index = drop_hyperedges_index_sp(hyperedge_index, num_edges, num_hyperedges, p)
    num_he_new = hyperedge_index[1].max().item() + 1

    full_edge_index = torch.arange(num_edges, dtype=torch.long, device=hyperedge_index.device)
    occured_edges = hyperedge_index[0].unique()

    isolated_edges_mask = torch.empty(num_edges, dtype=torch.bool, device=hyperedge_index.device).fill_(True)
    isolated_edges_mask[occured_edges] = False
    isolated_edges = full_edge_index[isolated_edges_mask]
    num_isolated_edges = isolated_edges.size(0)

    if num_isolated_edges == 0:
        return hyperedge_index, num_he_new

    new_he_idx = torch.arange(num_he_new, num_he_new + num_isolated_edges, 
                              dtype=torch.long, device=hyperedge_index.device)

    new_part = torch.vstack([isolated_edges, 
                             new_he_idx])

    hyperedge_index = torch.cat([hyperedge_index, new_part], dim=1)

    return hyperedge_index, num_he_new + num_isolated_edges


def drop_features_entry(X, p):
    """
    """

    mask = ((torch.rand(X.shape, device=X.device) > p).float()).detach()
    return X * mask


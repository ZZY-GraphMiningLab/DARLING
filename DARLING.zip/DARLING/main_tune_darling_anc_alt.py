import os
import gc
import sys
import time
import pickle
import argparse
from copy import deepcopy
from typing import Union
from tqdm import tqdm

from utils.init_envs import set_visible_gpus


parser = argparse.ArgumentParser(description='DarlingGSL arguments')

# Note: the search space of tunable hyperparameters is appended behind each argument below.

# General parameters
parser.add_argument('--dataset', type=str, default='pubmed', 
                    choices=['cora', 'citeseer', 'pubmed', 
                             'minesweeper', 'roman-empire', 'amazon-ratings'])
parser.add_argument('--expid', type=str, default="0")                                       
parser.add_argument('--model_name', type=str, default="DarlingGSL_Less")
parser.add_argument('--task_name', type=str, default="NCLS")
parser.add_argument('--log_dir', type=str, default='/root/logs/')
parser.add_argument('--ckp_dir', type=str, default='/root/checkpoints/')
parser.add_argument('--repetition', type=int, default=5)
parser.add_argument('--epoch_log_interval', type=int, default=5)
parser.add_argument('--device', type=int, default=0)
parser.add_argument('--seed', type=int, default=0)
parser.add_argument('--feat_norm', type=str, default='True', choices=['True', 'False'])     # [True, False]

# Psuedo-labeling
parser.add_argument('--pl_n_epochs', type=int, default=1000)    
parser.add_argument('--pl_nhid', type=int, default=32)                                      # [16, 32, 64, 128]
parser.add_argument('--pl_n_layers', type=int, default=2, choices=[2, 3])                   # [2, 3]
parser.add_argument('--pl_dropout', type=float, default=0.8)                                # [0, 0.8]
parser.add_argument('--pl_lr', type=float, default=0.1)                                     # [1e-1, 1e-4]
parser.add_argument('--pl_act', type=str, default='F.relu', choices=['F.relu', 'F.tanh'])
parser.add_argument('--pl_weight_decay', type=float, default=5e-4)                          # [5e-4, 5e-5, 5e-6, 5e-7, 0]

# GSL parameters
parser.add_argument('--gsl_use_init_stru_filter', type=int, default=1)  
parser.add_argument('--gsl_init_stru_filter_kept_ratio', type=float, default=0.9)           # [0.01, 0.7]

# Difficulty Measurer
parser.add_argument('--dmer_omega', type=float, default=0.6)                                # [0.0, 1.0]
parser.add_argument('--dmer_delta', type=float, default=0.1)                                # [0.0, 1.0]

# DHG ECL Pretraining
parser.add_argument('--edge_rep_dim', type=int, default=64)                                 # [16, 32, 64, 128, 256]
parser.add_argument('--hnn_encoder_n_layer', type=int, default=2, choices=[2, 3])           # [2, 3]
parser.add_argument('--dhg_ecl_proj_dim', type=int, default=64)                             # [64, 128, 256]
parser.add_argument('--dhg_ecl_lr', type=float, default=0.01)                               # [1e-4, 1.0]
parser.add_argument('--dhg_ecl_weight_decay', type=float, default=5e-4)                     # [5e-7, 5e-1]
parser.add_argument('--dhg_ecl_tau', type=float, default=0.3)                               # [0.1, 0.9]
parser.add_argument('--dhg_ecl_n_epochs', type=int, default=500)
parser.add_argument('--dhg_ecl_patience', type=int, default=100)        
parser.add_argument('--dhg_ecl_use_batch', type=int, default=1)         
parser.add_argument('--dhg_ecl_batch_size', type=int, default=8192)
parser.add_argument('--dhg_ecl_neg_num', type=int, default=8192)
parser.add_argument('--dhg_ecl_drop_incidence_rate', type=float, default=0.3)               # [0.0, 0.7]
parser.add_argument('--dhg_ecl_drop_feature_rate', type=float, default=0.3)                 # [0.0, 0.9]

# HEBF & HECL
parser.add_argument('--hebf_patience', type=float, default=50)          
parser.add_argument('--hebf_lr', type=float, default=0.01)                                  # [1e-4, 1.0]
parser.add_argument('--hebf_weight_decay', type=float, default=5e-4)                        # [5e-7, 5e-1]
parser.add_argument('--hebf_use_batch', type=int, default=1)            
parser.add_argument('--hebf_he_batch_size', type=int, default=2048)                         # Memory-related: 320, 512, 400
parser.add_argument('--hebf_reduce_method', type=str, default='mean')
parser.add_argument('--hebf_key_batch_ratio', type=float, default=0.5)               
parser.add_argument('--hebf_pair_num', type=int, default=300)                               # Memory-related: 100, 200, 64
parser.add_argument('--hebf_n_epochs', type=int, default=800)                        
parser.add_argument('--hebf_drop_hyperedge_rate', type=float, default=0.4)                  # [0.3, 0.9]
parser.add_argument('--hebf_drop_feature_rate', type=float, default=0.2)                    # [0.0, 0.7]
parser.add_argument('--hnn_encoder_dropout', type=float, default=0.2)                       # [0.0, 0.9]
parser.add_argument('--hebf_circle_m', type=float, default=0.25)                            # [-0.2, 0.4]
parser.add_argument('--hebf_circle_gamma', type=int, default=4)                             # [1, 10]
parser.add_argument('--hebf_circle_temp', type=float, default=0.3)                          # [0.1, 1.0]

# Graph Learning
parser.add_argument('--gl_n_epochs', type=int, default=20000)               
parser.add_argument('--gl_patience', type=int, default=3600)                
parser.add_argument('--gl_gnnr_lr', type=float, default=0.05)                               # [1e-4, 1.0]
parser.add_argument('--gl_gnnr_weight_decay', type=float, default=5e-4)                     # [5e-7, 5e-1]
parser.add_argument('--gl_gnnr_n_layers', type=int, default=2, choices=[2, 3])              # [2, 3]
parser.add_argument('--gl_gnnr_nhid', type=int, default=32)                                 # [16, 32, 64, 128]
parser.add_argument('--gl_gnnr_dropout', type=float, default=0.4)                           # [0.0, 0.9]
parser.add_argument('--gl_gnnr_act', type=str, default='F.relu', choices=['F.relu', 'F.tanh'])
parser.add_argument('--gl_gnnr_dropedge_rate_train', type=float, default=0.2)               # [0.0, 0.9]
parser.add_argument('--gl_gnnr_dropedge_rate_infer', type=float, default=0.2)               # [0.0, 0.7]
parser.add_argument('--gl_gler_n_models', type=int, default=4)                              # [1, 6]
parser.add_argument('--gl_gler_lr', type=float, default=0.1)                                # [1e-4, 1.0]
parser.add_argument('--gl_gler_weight_decay', type=float, default=5e-4)                     # [5e-7, 5e-1]
parser.add_argument('--gl_gler_n_layers', type=int, default=2)
parser.add_argument('--gl_gler_dropout_mlp', type=float, default=0.5)                       # [0.0, 0.9]
parser.add_argument('--gl_gler_hidden_channels', type=int, default=6)                       # [4, 14]

parser.add_argument('--gl_sim_mlp_type', type=str, default='diag', 
                    choices=['full', 'diag'])                                               # ['full', 'diag']
parser.add_argument('--gl_sim_mlp_lr', type=float, default=0.01)                            # [1e-4, 1.0]
parser.add_argument('--gl_sim_mlp_weight_decay', type=float, default=5e-4)                  # [5e-7, 5e-1]
parser.add_argument('--gl_sim_mlp_n_layers', type=int, default=2)
parser.add_argument('--gl_sim_mlp_dropout', type=float, default=0.3)                        # [0.0, 0.9]
parser.add_argument('--gl_sim_mlp_act', type=str, default='F.relu', 
                                           choices=['F.relu', 'F.tanh'])                    # ['F.relu', 'F.tanh']

parser.add_argument('--gl_mapper_lr', type=float, default=0.01)                             # [1e-5, 1e-1]
parser.add_argument('--gl_mapper_weight_decay', type=float, default=5e-4)                   # [5e-7, 5e-1]

parser.add_argument('--gl_ht_lr', type=float, default=0.001)                                # [1e-4, 1.0]
parser.add_argument('--gl_ht_weight_decay', type=float, default=0.0)                        # [5e-7, 5e-1]
parser.add_argument('--gl_ht_gnn_hidden_channels', type=int, default=512)                   # [16, 32, 64, 128, 256, 512]
parser.add_argument('--gl_ht_gnn_out_channels', type=int, default=256)                      # [16, 32, 64, 128, 256, 512]
parser.add_argument('--gl_ht_gnn_n_layers', type=int, default=2, choices=[2, 3])            # [2, 3]
parser.add_argument('--gl_ht_gnn_dropout', type=float, default=0.5)                         # [0.0, 0.9]
parser.add_argument('--gl_ht_proj_n_channels', type=int, default=256)                       # [16, 32, 64, 128, 256, 512]
parser.add_argument('--gl_ht_proj_n_layers', type=int, default=2)
parser.add_argument('--gl_ht_maskfeat_rate_learner', type=float, default=0.5)               # [0.0, 0.8]
parser.add_argument('--gl_ht_maskfeat_rate_anchor', type=float, default=0.5)                # [0.0, 0.7]
parser.add_argument('--gl_ht_batch_size', type=int, default=4096)                           # Memory-related: 4096, 512, 1024
parser.add_argument('--gl_ht_bootstrap_rate', type=float, default=0.9999)                   # [0.9, 0.99, 0.999, 0.9999, 0.99999, 1.0]
parser.add_argument('--gl_ht_bootstrap_interval', type=int, default=0)                      # [0, 60]
parser.add_argument('--gl_ht_dropedge_rate', type=float, default=0.25)                      # [0.0, 0.8]
parser.add_argument('--gl_alpha', type=float, default=0.1)                                  # [1e-4, 1e1]
parser.add_argument('--gl_theta', type=float, default=0.3)                                  # [1e-4, 1e1]
parser.add_argument('--gl_miu', type=float, default=0.9)                                    # [0.05, 0.95]
parser.add_argument('--gl_epsilon', type=float, default=0.1)                                # [0.0, 0.8]
parser.add_argument('--gl_max_he_size', type=int, default=30)                               # Memory-related: 16, 64
parser.add_argument('--gl_gnnrf_n_epochs', type=int, default=200)                           # [100, 700]
parser.add_argument('--gl_gler_n_epochs', type=int, default=300)                            # [100, 600]
parser.add_argument('--gl_curriculum_n_epochs', type=int, default=6000)                     # [2000, 16000]
parser.add_argument('--gl_curriculum_init_prop', type=float, default=0.001)                 # [0.001, 0.9]
parser.add_argument('--gl_precompute_batch_size_cross', 
                                type=lambda x: int(float(x)), default='3e5')                # Memory-related: 2e4, 4e4, 5e4
parser.add_argument('--gl_precompute_batch_size_inner', 
                                type=lambda x: int(float(x)), default='4e5')                # Memory-related: 1e3
parser.add_argument('--gl_anch_smp_num', type=int, default=700)                             # Memory-related: 600, 700

params = parser.parse_args().__dict__

if params['device'] >= 0:
    set_visible_gpus(str(params['device']))
else:
    set_visible_gpus('')

# check if the log directory exists
params['log_dir'] = os.path.join(params['log_dir'], f"{params['model_name']}")
if not os.path.exists(params['log_dir']):
    os.makedirs(params['log_dir'], exist_ok=True)

# check if the checkpoint directory exists
model_dump_dir = os.path.join(params['ckp_dir'], f"{params['model_name']}")

if not os.path.exists(model_dump_dir):
    os.makedirs(model_dump_dir, exist_ok=True)

from utils.process_args import process_args

params, warning_str = process_args(params)

from math import floor, ceil

import pandas as pd
import numpy as np

os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"

import torch
torch.backends.cudnn.benchmark = False
torch.use_deterministic_algorithms(mode=True, warn_only=False)


import torch.nn.functional as F
from torch import linalg as LA
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts
import random
import dgl

from utils.dataset import Dataset as OpengslDataset

from torch_scatter import segment_csr
from torch_sparse.index_select import index_select
from torch_sparse.tensor import SparseTensor
from torch_sparse import matmul

from model.gnns import GCN, GCN_Anchor, MLP, HyperEncoder_csr, MLP_Diag
from model.difficulty_measurer import difficulty_measurer_rank_tractable_hp_deg
from model.self_supervision import DHG_ECL, HEBF_csr, Head_Tail_Anc_GNN
from model.graph_learner import Graph_Learner_Similarity_Less_Ens as Graph_Learner_Similarity

from utils.logger import MyLogger, star_formatter, get_separator
from utils.procs import sym_norm_sp_tensor_tractable, unnorm_adj_sp, row_norm_dense, \
                        drop_incidence, drop_features_dim, \
                        drop_features_entry, drop_hyperedges_tensor, \
                        global_topk_sparsify_sp, add_self_loops_torch_sp, \
                        epsilon_sparsify_dense, \
                        add_remaining_self_loops_torch_sp, \
                        add_graph_mse_loss, \
                        add_graph_smooth_loss, \
                        sym_norm_dense_tensor, \
                        compute_anchor_adj_normed_dense, compute_unnorm_node_adj_sp, \
                        sparse_dropout
from utils.metrics import calculate_cls_metrics, calculate_pl_metrics


def set_seed(seed):
    '''
    Set seed to make sure the results can be repetitive.

    Parameters
    ----------
    seed : int
        Random seed to set.
    '''

    dgl.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.cuda.manual_seed_all(seed)


def train_pl_model_split(
    dataset: OpengslDataset=None, 
    split_id=0, 
    adj_normalized: torch.Tensor=None, 
    mylogger: MyLogger=None, 
    train_metrics_df: pd.DataFrame=None
):
    """
    """

    global params

    labels = dataset.labels

    train_masks = dataset.train_masks[split_id]
    val_masks = dataset.val_masks[split_id]
    feats = dataset.feats_normed if dataset.feats_normed is not None else dataset.feats

    pl_model = GCN(nfeat=dataset.dim_feats, nhid=params['pl_nhid'], nclass=dataset.n_classes, 
                   n_layers=params['pl_n_layers'], dropout=params['pl_dropout'], 
                   act=params['pl_act'], weight_initializer='uniform', 
                   n_linear=1, input_dropout=0, 
                   input_layer=False, output_layer=False, 
                   norm=None, bias=True).to(params['device'])

    optim = torch.optim.Adam(pl_model.parameters(), lr=params['pl_lr'], 
                                weight_decay=params['pl_weight_decay'])

    best_epoch = -1
    best_loss_val = 1e9
    best_met_val = -1
    best_pl_model_weights = None

    start_time = time.time()

    # use the normalized adjacency matrix for the training
    for epoch in range(params['pl_n_epochs']):
        t0 = time.time()

        # Train
        pl_model.train()
        optim.zero_grad()

        # get the log_softmax output & calculate the training metrics
        logp: torch.Tensor = pl_model(feats, adj_normalized, return_final=False)
        loss_train = F.nll_loss(logp[train_masks], labels[train_masks].long())
        met_train = calculate_cls_metrics(labels[train_masks].long().cpu().numpy(), 
                                          logp[train_masks].detach().cpu().numpy())

        # update the model by the training loss
        loss_train.backward()
        optim.step()

        # Evaluate on the validation set
        pl_model.eval()
        with torch.no_grad():
            logp: torch.Tensor = pl_model(feats, adj_normalized, return_final=False)
            loss_val = F.nll_loss(logp[val_masks], labels[val_masks].long())
            met_val = calculate_cls_metrics(labels[val_masks].long().cpu().numpy(), 
                                            logp[val_masks].detach().cpu().numpy())

        # save the best model
        if met_val > best_met_val or epoch == 0:
            best_epoch = epoch
            best_loss_val = loss_val
            best_met_val = met_val
            best_pl_model_weights = deepcopy(pl_model.state_dict())

        if epoch % params['epoch_log_interval'] == 0:
            mylogger.logger.info("Epoch {:05d} | Time(s) {:.4f} | Loss(train) {:.4f} | Met(train) {:.4f} | Loss(val) {:.4f} | Met(val) {:.4f}".format(
                                        epoch, time.time() - t0, loss_train.item(), met_train, loss_val.item(), met_val)
            )
            newline = pd.DataFrame({'stage': 'initial PL model training', 'split_id': split_id, 
                                    'pl_epoch': epoch, 'single_epoch_time': time.time() - t0, 
                                    'loss_train': loss_train.item(), 'met_train': met_train, 
                                    'loss_val': loss_val.item(), 'met_val': met_val}, index=[0])
            train_metrics_df = pd.concat([train_metrics_df, newline], axis=0)

    total_training_time = time.time() - start_time

    mylogger.logger.info('The best epoch: {} | The best val loss {:.4f} | The best val acc {:.4f}'.format(
                                        best_epoch, best_loss_val, best_met_val)
    )
    mylogger.logger.info('Total training time(s): {:.4f}'.format(total_training_time))

    pl_model.load_state_dict(best_pl_model_weights)
    pl_model.eval()
    with torch.no_grad():
        best_val_logp = pl_model(feats, adj_normalized)
        best_val_logp = best_val_logp.detach()

    del pl_model

    return best_met_val, best_pl_model_weights, best_val_logp, train_metrics_df


def pseudo_labeling_scalar(
    dataset: OpengslDataset=None, 
    split_id=0, 
    gnnr_best_val_logp=None, 
    mylogger: MyLogger=None, 
    train_metrics_df: pd.DataFrame=None
):

    train_masks = dataset.train_masks[split_id]

    with torch.no_grad():

        gnnr_best_val_logp = gnnr_best_val_logp.to(params['device'])

        _, pred_labels = torch.max(gnnr_best_val_logp, dim=1)

        # put the *training* labels back into the pseudo-labels
        pred_labels[train_masks] = dataset.labels[train_masks].long()

        # check the overall accuracy of the pseudo-labels
        overall_acc = calculate_pl_metrics(dataset.labels.long().cpu().numpy(), 
                                           pred_labels.detach().cpu().numpy(), 
                                           dataset.n_classes)

    mylogger.logger.info("The overall acc of PLs: {:.4f}".format(overall_acc))

    newline = pd.DataFrame({'stage': 'iterative pseudo-labeling', 'split_id': split_id, 
                            'pl_epoch': -1, 'single_epoch_time': -1, 
                            'loss_train': -1, 'met_train': -1, 
                            'loss_val': -1, 'met_val': -1}, index=[0])
    train_metrics_df = pd.concat([train_metrics_df, newline], axis=0)

    return pred_labels.detach(), train_metrics_df


def calculate_PL_feats_anc(
    dataset: OpengslDataset=None, 
    split_id=0, 
    gl_epoch=-1, 
    gnnr_best_val_logp=None, 
    best_gcn_reps: torch.Tensor=None, 
    normalized_adj: torch.Tensor=None, 
    ori_normalized_adj: torch.Tensor=None, 
    gl_anch_smp_num: int=-1, 
    selected_anchor_nodes: torch.Tensor=None, 
    mylogger: MyLogger=None
):
    """
    `normalized_adj`: N x S *node-anchor* adjacency matrix.
    """

    assert normalized_adj.shape[1] == gl_anch_smp_num, \
                "The input adjacency matrix should be an N x S matrix!"
    
    assert normalized_adj.shape[0] == dataset.n_nodes, \
                "The input adjacency matrix should be an N x S matrix!"
    
    assert selected_anchor_nodes.shape[0] == gl_anch_smp_num, \
                "The number of selected anchor nodes doesn't match!"

    train_masks = dataset.train_masks[split_id]

    torch.cuda.empty_cache()

    with torch.no_grad():

        gnnr_best_val_logp = gnnr_best_val_logp.to(params['device'])

        _, pred_labels = torch.max(gnnr_best_val_logp, dim=1)

        # put the *training* labels back into the pseudo-labels
        pred_labels[train_masks] = dataset.labels[train_masks].long()

        overall_acc = calculate_pl_metrics(dataset.labels.long().cpu().numpy(), 
                                           pred_labels.detach().cpu().numpy(), 
                                           dataset.n_classes)

        # calculate onehot label features
        pred_labels = pred_labels.int()
        pred_labels_onehot = torch.eye(dataset.n_classes, dtype=torch.float32, device=pred_labels.device)[pred_labels]

        grid_x, grid_y = torch.meshgrid(
            torch.arange(dataset.n_nodes, device=params['device'], dtype=torch.int32),
            torch.arange(gl_anch_smp_num, device=params['device'], dtype=torch.int32)
        )
        full_edge_indices : torch.Tensor = torch.vstack([grid_x.flatten(),
                                                         grid_y.flatten()])
        del grid_x, grid_y

        # local -> global
        full_edge_indices[1] = selected_anchor_nodes[full_edge_indices[1]]   # 2 x (N x S), 2D matrix

        edge_onehot_feats = 0.5* (
            pred_labels_onehot[full_edge_indices[0]] + 
            pred_labels_onehot[full_edge_indices[1]]
        )          # (N x S) x C, 2D matrix

        del pred_labels_onehot, full_edge_indices

        rec_indices = ori_normalized_adj.coalesce().indices()
        rec_indices = rec_indices[:, rec_indices[0]!=rec_indices[1]]

        # judge whether the two nodes belong to the same class
        edge_same_class_vec = (pred_labels[rec_indices[0]] == pred_labels[rec_indices[1]]).int()

        # aggregate & get the cnt
        indptr = torch._convert_indices_from_coo_to_csr(rec_indices[0], dataset.n_nodes, out_int32=False)       # row indices
        cnt = segment_csr(edge_same_class_vec, indptr, reduce='sum')
        deg = segment_csr(torch.ones_like(edge_same_class_vec), indptr, reduce='sum')
        deg = torch.where(deg <= 0.0, torch.tensor([1.0], device=deg.device, dtype=torch.float32), deg)

        inner_homo_feats = cnt / deg
        inner_homo_feats = inner_homo_feats.reshape(-1, 1)                      # N x 1

        # caculate the gcn reps similarity
        node_feats_sim_gcn_abs = LA.norm(best_gcn_reps, ord=2, dim=1)
        node_feats_sim_gcn_anc = best_gcn_reps[selected_anchor_nodes]
        node_feats_sim_gcn_anc_abs = LA.norm(node_feats_sim_gcn_anc, ord=2, dim=1)
        node_feats_sim_gcn = torch.einsum('ik,jk->ij', best_gcn_reps, node_feats_sim_gcn_anc) \
                / (torch.einsum('i,j->ij', node_feats_sim_gcn_abs, node_feats_sim_gcn_anc_abs) + 1e-12)
        del node_feats_sim_gcn_abs
        node_feats_sim_gcn = epsilon_sparsify_dense(node_feats_sim_gcn, 0.0, 0.0)

    mylogger.logger.info("GL epoch: {}, the overall acc of PLs: {:.4f}".format(gl_epoch, overall_acc))

    torch.cuda.empty_cache()

    return edge_onehot_feats.detach(), inner_homo_feats.detach(), node_feats_sim_gcn.detach()


def dhg_ecl_pretraining(
    mylogger: MyLogger=None, 
    train_metrics_df: pd.DataFrame=None, 
    num_all_he_dhg: int=None, 
    hnn_encoder: HyperEncoder_csr=None, 
    dhg_ecl_model: DHG_ECL=None, 
    optimizer_ecl: torch.optim.Optimizer=None, 
    edge_feats: torch.Tensor=None, 
    dhg_index: torch.Tensor=None
):
    """
    Borrowed from the `train` function in the code of `TriCL`.
    """

    global params

    bad_counter = 0
    best_loss = 1e9
    best_hnn_encoder_weights = None

    start_time = time.time()

    for dhg_ecl_epoch in range(params['dhg_ecl_n_epochs']):

        t0 = time.time()

        hnn_encoder.train()
        dhg_ecl_model.train()

        # Augmentation
        hyperedge_index1 = drop_incidence(dhg_index, params['dhg_ecl_drop_incidence_rate'])
        hyperedge_index2 = drop_incidence(dhg_index, params['dhg_ecl_drop_incidence_rate'])
        e1 = drop_features_dim(edge_feats, params['dhg_ecl_drop_feature_rate'])
        e2 = drop_features_dim(edge_feats, params['dhg_ecl_drop_feature_rate'])

        # Encoding
        e1 = hnn_encoder(e1, hyperedge_index1, num_all_he_dhg)
        e2 = hnn_encoder(e2, hyperedge_index2, num_all_he_dhg)

        # Projection (dual hypergraph node <==> graph edge)
        e1 = dhg_ecl_model.edge_projection(e1)
        e2 = dhg_ecl_model.edge_projection(e2)

        # Contrastive Loss
        if params['dhg_ecl_use_batch']:
            loss_n = dhg_ecl_model.edge_level_loss(e1, e2, params['dhg_ecl_tau'], 
                                                   batch_size=params['dhg_ecl_batch_size'], 
                                                   num_negs=None, 
                                                   mean=True)
        else:
            loss_n = dhg_ecl_model.edge_level_loss(e1, e2, params['dhg_ecl_tau'], 
                                                   batch_size=None,
                                                   num_negs=params['dhg_ecl_neg_num'], 
                                                   mean=True)

        loss = loss_n
        loss.backward()

        optimizer_ecl.step()
        optimizer_ecl.zero_grad(set_to_none=True)

        if loss.item() < best_loss or dhg_ecl_epoch == 0:
            bad_counter = 0
            best_loss = loss.item()
            best_hnn_encoder_weights = deepcopy(hnn_encoder.state_dict())
        else:
            bad_counter += 1

        if bad_counter >= params['dhg_ecl_patience']:
            mylogger.logger.info('DHG_ECL: Early Stopping!')
            break

        if dhg_ecl_epoch % params['epoch_log_interval'] == 0:
            mylogger.logger.info("Epoch {:05d} | Time(s) {:.4f} | Loss {:.4f}".format(
                                        dhg_ecl_epoch, time.time() - t0, loss.item())
            )
            newline = pd.DataFrame({'stage': 'DHG_ECL_pretraining', 
                                    'dhg_ecl_epoch': dhg_ecl_epoch, 'single_epoch_time': time.time() - t0, 
                                    'loss': loss}, index=[0])
            train_metrics_df = pd.concat([train_metrics_df, newline], axis=0)

    total_training_time = time.time() - start_time

    mylogger.logger.info('Total training time(s): {:.4f}'.format(total_training_time))

    hnn_encoder.eval()
    dhg_ecl_model.eval()

    torch.cuda.empty_cache()

    return best_hnn_encoder_weights, best_loss, train_metrics_df


def hebf_training(
    mylogger: MyLogger=None, 
    train_metrics_df: pd.DataFrame=None, 
    hnn_encoder: HyperEncoder_csr=None, 
    hebf_model: HEBF_csr=None, 
    optimizer_hgcl: torch.optim.Optimizer=None, 
    edge_feats: torch.Tensor=None, 
    dhg_index: torch.Tensor=None, 
    num_all_he_dhg: int=None
):

    global params

    edge_feats_gpu = edge_feats.to(params['device']).detach()

    num_all_e_dhg = edge_feats_gpu.shape[0]

    t1 = time.time()

    # generate the hyperedge dictionary (without loops) based on the *original* DHG index
    hebf_model.construct_HE_list_wto_loops(dhg_index)

    # generate the key-query pairs for HEBF loss computation
    # based on the *original* DHG index
    if params['hebf_use_batch']:
        hebf_model.generate_key_query_list_train(hebf_he_batch_size=params['hebf_he_batch_size'], 
                                           hebf_key_batch_ratio=params['hebf_key_batch_ratio'], 
                                           hebf_pair_num=params['hebf_pair_num'], 
                                           mylogger=mylogger, device=params['device'])

        hebf_model.generate_key_query_list_val(hebf_he_batch_size=4096, 
                                           hebf_key_batch_ratio=0.5, 
                                           hebf_pair_num=1, 
                                           mylogger=mylogger, device=params['device'])
    else:
        hebf_model.generate_key_query_list_train(hebf_he_batch_size=-1, 
                                           hebf_key_batch_ratio=params['hebf_key_batch_ratio'], 
                                           hebf_pair_num=params['hebf_pair_num'], 
                                           mylogger=mylogger, device=params['device'])

        hebf_model.generate_key_query_list_val(hebf_he_batch_size=-1, 
                                           hebf_key_batch_ratio=0.5, 
                                           hebf_pair_num=1, 
                                           mylogger=mylogger, device=params['device'])

    print("Time for preparation: ", time.time() - t1)

    bad_counter = 0
    best_pos_sim = 1e9
    best_hnn_encoder_weights = None
    best_hebf_model_weights = None

    start_time = time.time()

    dhgl_n_epochs = params['hebf_n_epochs']

    for hebf_epoch in range(dhgl_n_epochs):
        t0 = time.time()

        hnn_encoder.train()
        hebf_model.train()

        # Augmentation
        hyperedge_index_dropped, num_all_he_dhg_dd = drop_hyperedges_tensor(
                                                dhg_index, 
                                                num_all_e_dhg, 
                                                num_all_he_dhg, 
                                                params['hebf_drop_hyperedge_rate']
                                            )

        edges_processed = drop_features_entry(edge_feats_gpu, params['hebf_drop_feature_rate'])

        # Encoding & MP on the *augmented* DHG
        edges_processed = hnn_encoder(edges_processed, hyperedge_index_dropped, num_all_he_dhg_dd)

        # HEBF Loss
        hebf_loss = hebf_model.hebf_loss_train(edges_processed, reduce_method=params['hebf_reduce_method'])

        torch.cuda.empty_cache()

        hebf_loss.backward()
        optimizer_hgcl.step()
        optimizer_hgcl.zero_grad(set_to_none=True)

        hnn_encoder.eval()
        hebf_model.eval()

        with torch.no_grad():
            hebf_pos_sim_val = hebf_model.hebf_pos_sim_val(edges_processed, reduce_method=params['hebf_reduce_method'])

        del hyperedge_index_dropped
        del edges_processed

        if hebf_pos_sim_val.item() > best_pos_sim or hebf_epoch == 0:
            bad_counter = 0
            best_pos_sim = hebf_pos_sim_val.item()
            best_hnn_encoder_weights = deepcopy(hnn_encoder.state_dict())
            best_hebf_model_weights = deepcopy(hebf_model.state_dict())
        else:
            bad_counter += 1

        if bad_counter >= params['hebf_patience']:
            mylogger.logger.info('HEBF & HECL: Early Stopping!')
            break

        if hebf_epoch % params['epoch_log_interval'] == 0:
            mylogger.logger.info("Epoch {:05d} | Time(s) {:.4f} | HEBF Loss {:.8f}".format(
                                        hebf_epoch, time.time() - t0, hebf_loss.item())
            )
            newline = pd.DataFrame({'stage': 'hebf_training', 
                                    'hebf_epoch': hebf_epoch, 'single_epoch_time': time.time() - t0, 
                                    'hebf_loss': hebf_loss.item()}, index=[0])
            train_metrics_df = pd.concat([train_metrics_df, newline], axis=0)

    total_training_time = time.time() - start_time

    mylogger.logger.info('Total training time(s): {:.4f}'.format(total_training_time))

    hnn_encoder.eval()
    hebf_model.eval()

    totalHE_wto_loops = hebf_model.totalHE_wto_loops
    he_size_wto_loops = hebf_model.he_size_wto_loops

    torch.cuda.empty_cache()

    return best_hnn_encoder_weights, best_hebf_model_weights, \
            totalHE_wto_loops, he_size_wto_loops, best_pos_sim, train_metrics_df


def sample_edges_anc(
    sample_scores_anc: torch.Tensor,            # *2D* dense adj matrix, *anchor*
    curriculum_epoch: int, 
):
    """
    Return the edge indices of the sampled edges in the *anchor* matrix.
    """

    global params

    assert sample_scores_anc is not None
    assert sample_scores_anc.dim() == 2
    assert sample_scores_anc.shape[0] > sample_scores_anc.shape[1]     # anchor adj matrix
    assert curriculum_epoch >= 0

    num_all_edges = sample_scores_anc.shape[0] * sample_scores_anc.shape[1]

    assert sample_scores_anc.is_cuda

    # calculate the proportion of the refined edges
    # root-0.5
    curriculum_prop = torch.min(torch.tensor(1.0, dtype=torch.float64), 
                                (torch.pow(torch.tensor(params['gl_curriculum_init_prop'], dtype=torch.float64), 2.0) + 
                                (1.0 - torch.pow(torch.tensor(params['gl_curriculum_init_prop'], dtype=torch.float64), 2.0)) *
                                (curriculum_epoch / torch.tensor(params['gl_curriculum_n_epochs'], dtype=torch.float64))).sqrt())

    # calculate the number of intended edges
    curriculum_num = torch.floor(torch.tensor(num_all_edges, dtype=torch.float64) * curriculum_prop).long()

    # topk selection
    _, selected_edges = torch.sort(sample_scores_anc.flatten(), descending=True, stable=True)
    selected_edges = selected_edges[:curriculum_num]

    del _

    # transform the 1D indices to 2D indices
    selected_edges = torch.vstack([selected_edges // sample_scores_anc.shape[1],
                                   selected_edges %  sample_scores_anc.shape[1]])

    return selected_edges


def graph_learner_forward(
    gl_anch_smp_num: int, 
    selected_anchor_nodes: torch.Tensor, 
    sample_scores_anc: torch.Tensor, 
    adj_refined : torch.Tensor, 
    full_edge_indices: torch.Tensor, 
    full_flatten_indices: torch.Tensor, 
    cross_sim: torch.Tensor, 
    cross_sim_inv: torch.Tensor, 
    inner_sim: torch.Tensor, 
    edge_onehot_feats: torch.Tensor, 
    inner_homo_feats : torch.Tensor, 
    node_feats_sim_gcn: torch.Tensor, 
    total_he_feats: torch.Tensor, 
    curriculum_epoch: int, 
    dataset: OpengslDataset, 
    params: dict, 
    graph_learner: Graph_Learner_Similarity, 
    sim_mlp: Union[MLP, MLP_Diag], 
    hebf_model: HEBF_csr, 
    mylogger: MyLogger, 
    is_train: bool=True
):

    torch.cuda.empty_cache()

    # Step 1: create a deepcopy of `adj_refined` to avoid the in-place operation!
    adj_refined = adj_refined.detach().to(params['device'], copy=True)      # cpu -> gpu, deepcopy

    # Step 2: sample all the edges
    if is_train:
        with torch.no_grad():
            edge_indices = sample_edges_anc(
                                sample_scores_anc, 
                                curriculum_epoch, 
                                mylogger
                            )
    else:
        assert full_edge_indices is not None
        assert full_flatten_indices is not None
        assert full_edge_indices.is_cuda
        assert full_flatten_indices.is_cuda
        edge_indices = full_edge_indices

    # Step 3: generate the node similarity (GCN & MLP)
    node_feats_sim_mlp = sim_mlp(dataset.feats)
    node_feats_sim_mlp_abs = LA.norm(node_feats_sim_mlp, ord=2, dim=1)
    total_feats_sim_mlp_anc = node_feats_sim_mlp[selected_anchor_nodes]
    total_feats_sim_mlp_anc_abs = LA.norm(total_feats_sim_mlp_anc, ord=2, dim=1)
    node_feats_sim_mlp = torch.einsum('ik,jk->ij', node_feats_sim_mlp, total_feats_sim_mlp_anc) \
                / (torch.einsum('i,j->ij', node_feats_sim_mlp_abs, total_feats_sim_mlp_anc_abs) + 1e-12)

    # Step 4: generate the hyperedge similarity (i: query, j: key)
    he_feats_query = hebf_model.query_mapper(total_he_feats)
    he_feats_key = hebf_model.key_mapper(total_he_feats[selected_anchor_nodes])
    he_feats_query_abs = LA.norm(he_feats_query, ord=2, dim=1)
    he_feats_key_abs = LA.norm(he_feats_key, ord=2, dim=1)
    he_feats_sim = torch.einsum('ik,jk->ij', he_feats_query, he_feats_key) \
        / (torch.einsum('i,j->ij', he_feats_query_abs, he_feats_key_abs) + 1e-12)

    # filter out all the negative entries here
    node_feats_sim_mlp = epsilon_sparsify_dense(node_feats_sim_mlp, 0.0, 0.0)
    he_feats_sim = epsilon_sparsify_dense(he_feats_sim, 0.0, 0.0)

    # Step 5: get the edge predictions
    if not is_train:
        probs = graph_learner(
            node_feats_sim_gcn, 
            node_feats_sim_mlp, 
            inner_homo_feats, 
            inner_sim, 
            cross_sim, 
            cross_sim_inv, 
            he_feats_sim, 
            edge_onehot_feats, 
            edge_indices, full_flatten_indices, 
            gl_anch_smp_num, 
            is_train, 
            selected_anchor_nodes, 
            is_anchor=True
        ).squeeze()
    else:
        probs = graph_learner(
            node_feats_sim_gcn, 
            node_feats_sim_mlp, 
            inner_homo_feats, 
            inner_sim, 
            cross_sim, 
            cross_sim_inv, 
            he_feats_sim, 
            edge_onehot_feats, 
            edge_indices, None, 
            gl_anch_smp_num, 
            is_train, 
            selected_anchor_nodes, 
            is_anchor=True
        ).squeeze()

    # back-fill the probs into the *dense* matrix
    adj_refined[edge_indices[0], edge_indices[1]] = probs

    # sparsify the dense matrix when not in training mode
    if not is_train:
        adj_refined = epsilon_sparsify_dense(adj_refined, params['gl_epsilon'], 0.0)

    if is_train:
        return adj_refined, edge_indices            # for MSE loss
    else:
        return adj_refined


def generate_full_sample_scores_anc(
    node_difficulty: torch.Tensor, 
    selected_anchor_nodes: torch.Tensor
):

    node_difficulty = node_difficulty.to(params['device'])
    node_difficulty_anc = node_difficulty[selected_anchor_nodes]
    return torch.outer(1 - node_difficulty, 1 - node_difficulty_anc)


def tensor_max_clip(tensor, max_val):
    return torch.clamp(tensor, min=None, max=max_val)


def get_edge_indices(he_size_wto_loops_list, totalHE_wto_loops, he_idx_list: list, max_he_size: int):
    edge_indices = []
    for he_idx in he_idx_list:
        # restrict the number of sampled edges
        if he_size_wto_loops_list[he_idx] > max_he_size:
            edge_indices += totalHE_wto_loops[he_idx][:max_he_size]
        else:
            edge_indices += totalHE_wto_loops[he_idx]
    return torch.tensor(edge_indices, dtype=torch.long, device=params['device'])


def batch_compute_cross_similarities_anc(
    selected_anchor_nodes: torch.Tensor,
    full_HE_indices_gpu, 
    he_size_wto_loops_gpu, 
    he_size_wto_loops_list, 
    total_edge_feats_gpu, 
    totalHE_wto_loops, 
    t_start, t_end, 
    is_inverse=False
):

    batch_HE_indices = full_HE_indices_gpu[:, t_start: t_end].detach().clone()

    # local -> global
    if is_inverse:
        batch_HE_indices[0] = selected_anchor_nodes[batch_HE_indices[0]]
    else:
        batch_HE_indices[1] = selected_anchor_nodes[batch_HE_indices[1]]

    batch_HE_indices_list = batch_HE_indices.tolist()

    # Step 1
    rep_cnt = torch.repeat_interleave(
        tensor_max_clip(he_size_wto_loops_gpu[batch_HE_indices[1]], params['gl_max_he_size']), 
        tensor_max_clip(he_size_wto_loops_gpu[batch_HE_indices[0]], params['gl_max_he_size'])
    )

    # Step 2
    Es_row1 = get_edge_indices(he_size_wto_loops_list, totalHE_wto_loops, batch_HE_indices_list[0], params['gl_max_he_size'])
    Es_row1_ori_len = Es_row1.shape[0]
    Es_row1 = torch.repeat_interleave(Es_row1, rep_cnt)

    # Step 3
    Es_row2 = []
    for i in range(batch_HE_indices.shape[1]):
        temp_size = he_size_wto_loops_list[batch_HE_indices_list[0][i]]
        if temp_size > params['gl_max_he_size']:
            temp_size = params['gl_max_he_size']
        Es_row2 += totalHE_wto_loops[batch_HE_indices_list[1][i]][:params['gl_max_he_size']] * temp_size
    Es_row2 = torch.tensor(Es_row2, dtype=torch.long, device=params['device'])

    # Step 4
    cross_sim = F.cosine_similarity(
        total_edge_feats_gpu[Es_row1], 
        total_edge_feats_gpu[Es_row2], 
        dim=1, 
        eps=1e-10
    )

    del Es_row1, Es_row2

    cross_sim = epsilon_sparsify_dense(cross_sim, 0.0, 0.0)

    # Step 5
    mean_pooling_indices = torch.repeat_interleave(
        torch.arange(Es_row1_ori_len, 
                     device=params['device'], dtype=torch.long), 
        rep_cnt
    )

    del rep_cnt

    max_pooling_indices = torch.repeat_interleave(
        torch.arange(batch_HE_indices.shape[1], 
                     device=params['device'], dtype=torch.long), 
        tensor_max_clip(he_size_wto_loops_gpu[batch_HE_indices[0]], params['gl_max_he_size'])
    )

    # Step 6
    indptr = torch._convert_indices_from_coo_to_csr(mean_pooling_indices, Es_row1_ori_len, out_int32=False)
    cross_sim = segment_csr(cross_sim, indptr, reduce='mean')
    del mean_pooling_indices
    indptr = torch._convert_indices_from_coo_to_csr(max_pooling_indices, batch_HE_indices.shape[1], out_int32=False)
    del max_pooling_indices
    cross_sim = segment_csr(cross_sim, indptr, reduce='max')
    cross_sim = cross_sim.unsqueeze(-1)

    torch.cuda.empty_cache()

    return cross_sim       # a col vector


def compute_inner_similarities_anc(
    selected_anchor_nodes: torch.Tensor, 
    full_HE_indices_cpu, 
    he_size_wto_loops_gpu, 
    he_size_wto_loops_list, 
    total_edge_feats_gpu, 
    totalHE_wto_loops, 
    params: dict, 
    reorg_perm_idx: torch.Tensor
):
    """
    """

    max_he_size_inner = 100000

    full_HE_indices_gpu = full_HE_indices_cpu.to(params['device'], copy=True).detach()

    # local -> global
    full_HE_indices_gpu[1] = selected_anchor_nodes[full_HE_indices_gpu[1]]

    occured_nodes, HE_inverse_indices = torch.unique(full_HE_indices_gpu.flatten(), return_inverse=True)        # 0: i || 1: j -> A_ij

    n_batch_inner = ceil(occured_nodes.shape[0] / params['gl_precompute_batch_size_inner'])

    inner_sim = []
    for batch_id in tqdm(range(n_batch_inner)):
        t_start = int(batch_id * params['gl_precompute_batch_size_inner'])
        t_end = int((batch_id + 1) * params['gl_precompute_batch_size_inner'])

        occured_nodes_batch = occured_nodes[t_start: t_end]
        occured_nodes_batch_list = occured_nodes_batch.tolist()

        # Step 1
        tmp_cnt = tensor_max_clip(he_size_wto_loops_gpu[occured_nodes_batch], max_he_size_inner)
        rep_cnt = torch.repeat_interleave(tmp_cnt - 1, tmp_cnt)
        del tmp_cnt

        # Step 2
        Es_occ = get_edge_indices(he_size_wto_loops_list, totalHE_wto_loops, occured_nodes_batch_list, max_he_size_inner)
        Es_occ_ori_len = Es_occ.shape[0]
        Es_occ = torch.repeat_interleave(Es_occ, rep_cnt)

        # Step 3
        Es_row2 = []
        for idx_n in occured_nodes_batch_list:
            Es_tmp = totalHE_wto_loops[idx_n][:max_he_size_inner]
            for i in range(len(Es_tmp)):
                Es_row2 += Es_tmp[:i] + Es_tmp[i + 1:]
        Es_row2 = torch.tensor(Es_row2, dtype=torch.long, device=params['device'])

        # Step 4
        inner_sim_batch = F.cosine_similarity(
            total_edge_feats_gpu[Es_occ], 
            total_edge_feats_gpu[Es_row2], 
            dim=1, 
            eps=1e-10
        )

        del Es_occ, Es_row2

        inner_sim_batch = epsilon_sparsify_dense(inner_sim_batch, 0.0, 0.0)

        # Step 5
        fst_mean_pooling_indices = torch.repeat_interleave(
            torch.arange(Es_occ_ori_len, 
                         device=params['device'], dtype=torch.long), 
            rep_cnt
        )

        del rep_cnt

        snd_mean_pooling_indices = torch.repeat_interleave(
            torch.arange(occured_nodes_batch.shape[0], 
                         device=params['device'], dtype=torch.long), 
            tensor_max_clip(he_size_wto_loops_gpu[occured_nodes_batch], max_he_size_inner)
        )

        # Step 6
        indptr = torch._convert_indices_from_coo_to_csr(fst_mean_pooling_indices, Es_occ_ori_len, out_int32=False)
        del fst_mean_pooling_indices
        inner_sim_batch = segment_csr(inner_sim_batch, indptr, reduce='mean')
        indptr = torch._convert_indices_from_coo_to_csr(snd_mean_pooling_indices, occured_nodes_batch.shape[0], out_int32=False)
        del snd_mean_pooling_indices
        inner_sim_batch = segment_csr(inner_sim_batch, indptr, reduce='mean')

        del indptr
        del occured_nodes_batch

        inner_sim.append(inner_sim_batch)                 # organised by the `occured_nodes_batch`

        torch.cuda.empty_cache()

    inner_sim = torch.cat(inner_sim, dim=0)               # size: `occured_nodes.shape[0]`

    # Step 7
    row_seg_point = HE_inverse_indices.shape[0] // 2
    row1 = inner_sim[HE_inverse_indices[:row_seg_point]]    # 0: i
    row2 = inner_sim[HE_inverse_indices[row_seg_point:]]    # 1: j

    del HE_inverse_indices

    # back to the random order
    inner_sim = torch.cat([row1.unsqueeze(-1), 
                           row2.unsqueeze(-1)], dim=1)    # [0: i, 1: j], size: `full_edge_indices.shape[1]` x 2

    # back to the original order
    inner_sim = inner_sim[reorg_perm_idx, :]              # re-organise the indices

    return inner_sim


def precompute_similarities_csr_anc(
    gl_anch_smp_num: int, 
    selected_anchor_nodes: torch.Tensor, 
    total_edge_feats: torch.Tensor=None, 
    totalHE_wto_loops: list=None, 
    he_size_wto_loops_list: list=None, 
    total_node_num: int=None, 
    mylogger: MyLogger=None
):
    """
    """

    he_size_wto_loops_gpu : torch.Tensor = torch.tensor(
        he_size_wto_loops_list, 
        dtype=torch.long, 
        device=params['device']
    )

    total_edge_feats_gpu = total_edge_feats.to(params['device'], non_blocking=True).detach()

    grid_x, grid_y = torch.meshgrid(torch.arange(total_node_num, device=params['device'], dtype=torch.long),
                                    torch.arange(gl_anch_smp_num, device=params['device'], dtype=torch.long))
    full_HE_indices_gpu : torch.Tensor = torch.vstack([grid_x.flatten(),        # 0: i, 1: j -> R_ij
                                                       grid_y.flatten()])       # *local* indices! (anchor matrix)
    del grid_x, grid_y

    # create a random permutation of the full edge indices to avoid memory issues
    rand_perm_idx = torch.randperm(full_HE_indices_gpu.shape[1], device=params['device'])
    reorg_perm_idx = torch.argsort(rand_perm_idx, dim=0)
    full_HE_indices_gpu = full_HE_indices_gpu[:, rand_perm_idx]

    n_batch_cross = ceil(full_HE_indices_gpu.shape[1] / params['gl_precompute_batch_size_cross'])

    # compute the cross-similarities
    mylogger.logger.info("Start computing the cross-similarities (E~E)...")
    cross_sim = []
    for batch_id in tqdm(range(n_batch_cross)):
        t_start = int(batch_id * params['gl_precompute_batch_size_cross'])
        t_end = int((batch_id + 1) * params['gl_precompute_batch_size_cross'])

        cross_sim_batch = batch_compute_cross_similarities_anc(
            selected_anchor_nodes, 
            full_HE_indices_gpu, 
            he_size_wto_loops_gpu, 
            he_size_wto_loops_list, 
            total_edge_feats_gpu, 
            totalHE_wto_loops, 
            t_start, t_end, 
            is_inverse=False
        )

        cross_sim.append(cross_sim_batch)

    cross_sim = torch.cat(cross_sim, dim=0)               # a col vector, size: `full_edge_indices.shape[1]` x 1
    cross_sim = cross_sim[reorg_perm_idx, :]              # re-organise the indices

    # compute the inner-similarities
    mylogger.logger.info("Start computing the inner-similarities (E~E)...")
    full_HE_indices_gpu = full_HE_indices_gpu.to('cpu', copy=True).detach()
    inner_sim = compute_inner_similarities_anc(
        selected_anchor_nodes, 
        full_HE_indices_gpu, 
        he_size_wto_loops_gpu, 
        he_size_wto_loops_list, 
        total_edge_feats_gpu, 
        totalHE_wto_loops, 
        params, 
        reorg_perm_idx
    )
    full_HE_indices_gpu = full_HE_indices_gpu.to(params['device'], copy=True).detach()

    # compute the inverse cross-similarities
    cross_sim_inv = []
    full_HE_indices_gpu = full_HE_indices_gpu.flip(0)
    for batch_id in tqdm(range(n_batch_cross)):
        t_start = int(batch_id * params['gl_precompute_batch_size_cross'])
        t_end = int((batch_id + 1) * params['gl_precompute_batch_size_cross'])

        cross_sim_inv_batch = batch_compute_cross_similarities_anc(
            selected_anchor_nodes, 
            full_HE_indices_gpu, 
            he_size_wto_loops_gpu, 
            he_size_wto_loops_list, 
            total_edge_feats_gpu, 
            totalHE_wto_loops, 
            t_start, t_end, 
            is_inverse=True
        )

        cross_sim_inv.append(cross_sim_inv_batch)

    cross_sim_inv = torch.cat(cross_sim_inv, dim=0)       # a col vector, size: `full_edge_indices.shape[1]` x 1
    cross_sim_inv = cross_sim_inv[reorg_perm_idx, :]      # re-organise the indices
    del reorg_perm_idx, rand_perm_idx

    torch.cuda.empty_cache()

    return cross_sim.detach(), inner_sim.detach(), cross_sim_inv.detach()


def generate_full_edge_indices_anc(total_node_num, gl_anch_smp_num):
    """
    Generate the full edge indices for the curriculum learning.
    """

    grid_x, grid_y = torch.meshgrid(
        torch.arange(total_node_num, device=params['device'], dtype=torch.long),
        torch.arange(gl_anch_smp_num, device=params['device'], dtype=torch.long)
    )
    full_edge_indices : torch.Tensor = torch.vstack([grid_x.flatten(),
                                                     grid_y.flatten()])
    del grid_x, grid_y

    full_edge_indices = full_edge_indices.detach()

    # calculate the flatten indices by `full_edge_indices`
    full_flatten_indices = full_edge_indices[0] * gl_anch_smp_num + full_edge_indices[1]
    full_flatten_indices = full_flatten_indices.detach()

    return full_edge_indices, full_flatten_indices          # gpu


def sample_anc_nodes(
    node_difficulty: torch.Tensor, 
):
    """
    Sample the selected nodes for GLer training.

    It's based on the node difficulty scores.
    """

    global params

    num_nodes = node_difficulty.shape[0]

    # sort the nodes by their sample scores & select the top-k easiest nodes
    if params['gl_anch_smp_num'] >= num_nodes:
        _, selected_nodes = torch.sort(1 - node_difficulty, descending=True, stable=True)
        selected_nodes = selected_nodes[:num_nodes]
    else:
        _, selected_nodes = torch.sort(1 - node_difficulty, descending=True, stable=True)
        selected_nodes = selected_nodes[:params['gl_anch_smp_num']]

    # sort the selected nodes in ascending order
    selected_nodes = torch.sort(selected_nodes, descending=False, stable=True)[0]

    return selected_nodes


def graph_learning_refinement(
    dataset: OpengslDataset=None, 
    split_id: int=0, mylogger: MyLogger=None, 
    train_metrics_df: pd.DataFrame=None, 
    graph_learner: Graph_Learner_Similarity=None, 
    gcn_model: GCN_Anchor=None, sim_mlp: Union[MLP, MLP_Diag]=None, 
    ht_model: Head_Tail_Anc_GNN=None, 
    hebf_model: HEBF_csr=None, 
    optimizer_gler: torch.optim.Optimizer=None, 
    scheduler_gler: CosineAnnealingWarmRestarts=None, 
    optimizer_ht: torch.optim.Optimizer=None, 
    optimizer_gnnrf: torch.optim.Optimizer=None, 
    optimizer_sim_mlp: torch.optim.Optimizer=None, 
    total_edge_feats: torch.Tensor=None, 
    total_he_feats: torch.Tensor=None, 
    ori_adj_normalized: torch.Tensor=None, 
    iter_adj_unnormalized_weighted: torch.Tensor=None, 
    node_difficulty: torch.Tensor=None, 
    totalHE_wto_loops: list=None, 
    he_size_wto_loops_list: list=None, 
):
    """
    """

    global params

    labels = dataset.labels
    train_masks = dataset.train_masks[split_id]
    val_masks = dataset.val_masks[split_id]

    bad_counter = 0
    best_epoch = -1
    best_met_val = -1
    best_val_logp = None
    edge_onehot_feats, inner_homo_feats, node_feats_sim_gcn = None, None, None
    best_gcn_reps = None

    # best model weights
    best_gler_model_weights = deepcopy(graph_learner.state_dict())
    best_gnnrf_model_weights = deepcopy(gcn_model.state_dict())
    best_sim_mlp_weights = deepcopy(sim_mlp.state_dict())
    best_ht_model_weights = deepcopy(ht_model.state_dict())

    # *last* gnnrf training epoch's best model weights (for gnnrf training)
    last_gnnrf_model_weights = deepcopy(gcn_model.state_dict())

    # sample the anchor nodes
    # local -> global
    with torch.no_grad():
        selected_anchor_nodes = sample_anc_nodes(node_difficulty)

    # get the sampled graph using the anchor nodes
    with torch.no_grad():
        iter_adj_unnormalized_weighted_gpu = iter_adj_unnormalized_weighted.to(params['device'])
        iter_adj_unnormalized_weighted_gpu : SparseTensor = \
                 SparseTensor.from_torch_sparse_coo_tensor(iter_adj_unnormalized_weighted_gpu)
        sampled_graph = index_select(iter_adj_unnormalized_weighted_gpu, 1, selected_anchor_nodes)      # unnormalized sp
        sampled_graph = sampled_graph.to_dense()                                         # unnormalized dense anchor matrix

        best_adj_refined = sampled_graph.to(params['device'], copy=True).detach()        # gpu, unnormalized dense anchor matrix

    # Initialize the `anchor_adj` for MSE loss computation
    with torch.no_grad():
        anchor_adj = sampled_graph.to(params['device'], copy=True).detach()        # gpu
        anchor_adj = row_norm_dense(anchor_adj).detach()                                                 # gpu, for the mse loss
        iter_adj_unnormalized_weighted_gpu = iter_adj_unnormalized_weighted_gpu.to_torch_sparse_coo_tensor()
        iter_adj_normalized_weighted_gpu = sym_norm_sp_tensor_tractable(iter_adj_unnormalized_weighted_gpu, 
                                                    add_loop=True, device=params['device']).detach()     # gpu, for the anchor view in ht_model
    del iter_adj_unnormalized_weighted_gpu

    # Create the full sample scores for training edge sampling
    mylogger.logger.info("Generating the full sample scores...")

    t0 = time.time()
    with torch.no_grad():
        sample_scores_anc = generate_full_sample_scores_anc(node_difficulty, selected_anchor_nodes)
    sample_scores_anc = sample_scores_anc.detach()      # gpu

    mylogger.logger.info("Time for generating the full sample scores: {:.4f}".format(time.time() - t0))

    # Precompute the similarities
    mylogger.logger.info("Precomputing the similarities...")

    t0 = time.time()
    with torch.no_grad():
        torch.cuda.empty_cache()
        cross_sim, inner_sim, cross_sim_inv = precompute_similarities_csr_anc(
            params['gl_anch_smp_num'], selected_anchor_nodes, 
            total_edge_feats, totalHE_wto_loops, 
            he_size_wto_loops_list, 
            dataset.n_nodes, mylogger
        )           # gpu

    mylogger.logger.info("Time for precomputing the similarities: {:.4f}".format(time.time() - t0))

    total_he_feats = total_he_feats.to(params['device'], non_blocking=True).detach()         # gpu

    # generate the full edge indices
    mylogger.logger.info("Generating the full edge indices...")

    t0 = time.time()

    with torch.no_grad():
        full_edge_indices, full_flatten_indices = generate_full_edge_indices_anc(dataset.n_nodes, params['gl_anch_smp_num'])   # gpu, *local* indices

    mylogger.logger.info("Time for generating the full edge indices: {:.4f}".format(time.time() - t0))

    gl_gler_epoch = 0
    gl_gnnrf_epoch = 0
    gl_curriculum_epoch = 0
    train_gler = False      # train the gnnrf model first
    is_R_updated = False

    ht_loss = torch.tensor([-1], device=params['device'])
    reg_loss = torch.tensor([-1], device=params['device'])

    optimizer_mapper = torch.optim.Adam(hebf_model.parameters(), 
        lr=params['gl_mapper_lr'], weight_decay=params['gl_mapper_weight_decay'])

    start_time = time.time()

    ori_adj_normalized_gpu = ori_adj_normalized.to(params['device'])        # a sparse mx

    for gl_epoch in range(params['gl_n_epochs']):

        t0 = time.time()

        # fix the parameters of the gnnrf model & train the graph learner model
        if train_gler is False and gl_gnnrf_epoch < params['gl_gnnrf_n_epochs']:    # init & gnnrf training
            gcn_model.train()
            ht_model.eval()
            graph_learner.eval()
            sim_mlp.eval()
            hebf_model.eval()
            # unfreeze the parameters of the gnnrf model
            for param in gcn_model.parameters():
                param.requires_grad = True
        elif train_gler is False and gl_gnnrf_epoch >= params['gl_gnnrf_n_epochs']: # switch to the gler training
            train_gler = True
            gl_gler_epoch = 0
            last_gnnrf_model_weights = deepcopy(gcn_model.state_dict())             
            if best_gnnrf_model_weights is not None:
                gcn_model.load_state_dict(best_gnnrf_model_weights)                 # use the *best* gnnrf model
            gcn_model.eval()        # turn off the dropout in the gnnrf model
            ht_model.train()
            graph_learner.train()
            sim_mlp.train()
            hebf_model.train()
            # freeze the parameters of the gnnrf model
            for param in gcn_model.parameters():
                param.requires_grad = False
        elif train_gler is True and gl_gler_epoch >= params['gl_gler_n_epochs']:    # switch to the gnnrf training
            train_gler = False
            gl_gnnrf_epoch = 0
            gcn_model.load_state_dict(last_gnnrf_model_weights)                     
            gcn_model.train()
            ht_model.eval()
            graph_learner.eval()
            sim_mlp.eval()
            hebf_model.eval()
            # unfreeze the parameters of the gnnrf model
            for param in gcn_model.parameters():
                param.requires_grad = True
        elif train_gler is True and gl_gler_epoch < params['gl_gler_n_epochs']:     # gler training
            gcn_model.eval()        # turn off the dropout in the gnnrf model
            ht_model.train()
            graph_learner.train()
            sim_mlp.train()
            hebf_model.train()
            # freeze the parameters of the gnnrf model
            for param in gcn_model.parameters():
                param.requires_grad = False
        else:
            mylogger.logger.info("Error: The training stage is not correct!")
            break

        if train_gler:
            adj_refined_train, edge_indices = graph_learner_forward(
                                                params['gl_anch_smp_num'], 
                                                selected_anchor_nodes, 
                                                sample_scores_anc, 
                                                sampled_graph, 
                                                None, None, 
                                                cross_sim, cross_sim_inv, 
                                                inner_sim, edge_onehot_feats, 
                                                inner_homo_feats, node_feats_sim_gcn, 
                                                total_he_feats, 
                                                gl_curriculum_epoch, 
                                                dataset, params, graph_learner, 
                                                sim_mlp, hebf_model, 
                                                mylogger, 
                                                is_train=True
                                            )

            pred_anc = row_norm_dense(adj_refined_train)
            reg_loss = add_graph_mse_loss(
                pred=pred_anc[edge_indices[0], edge_indices[1]], 
                label=anchor_adj[edge_indices[0], edge_indices[1]],  
                loss_weight=params['gl_theta']
            )

            # HT loss
            features_learner = drop_features_dim(dataset.feats, params['gl_ht_maskfeat_rate_learner'])
            features_anchor = drop_features_dim(dataset.feats, params['gl_ht_maskfeat_rate_anchor'])

            features_anchor = ht_model.gnn_model(
                                    features_anchor, 
                                    sparse_dropout(ori_adj_normalized_gpu, params['gl_ht_dropedge_rate']), 
                                    None, 
                                    miu=None, return_final=True, 
                                    use_anchor=False, use_balance=True, 
                                    return_mid=False
                                )                               # final reps

            features_learner = ht_model.gnn_model(
                                    features_learner, 
                                    None, 
                                    F.dropout(adj_refined_train, p=params['gl_ht_dropedge_rate'], training=True, inplace=False), 
                                    miu=None, return_final=True, 
                                    use_anchor=True, use_balance=False, 
                                    return_mid=False            # for ht!
                                )                               # final reps, no ori_adj

            features_learner = ht_model.proj_feats(features_learner)
            features_anchor = ht_model.proj_feats(features_anchor)

            ht_loss = ht_model.loss(features_learner, features_anchor, params)

            # perform normal MP (`gcn_model` is *freezed*)
            logp = gcn_model(
                dataset.feats_normed if dataset.feats_normed is not None else dataset.feats, 
                sparse_dropout(ori_adj_normalized_gpu, params['gl_gnnr_dropedge_rate_infer']), 
                F.dropout(adj_refined_train, p=params['gl_gnnr_dropedge_rate_infer'], training=True, inplace=False), 
                miu=params['gl_miu'], 
                return_mid=False, use_anchor=True, 
                use_balance=True, return_final=False
            )  # sfmx

        else:

            adj_train = best_adj_refined

            if is_R_updated:
                logp = gcn_model(
                    dataset.feats_normed if dataset.feats_normed is not None else dataset.feats, 
                    sparse_dropout(ori_adj_normalized_gpu, params['gl_gnnr_dropedge_rate_train']), 
                    F.dropout(adj_train, p=params['gl_gnnr_dropedge_rate_train'], training=True, inplace=False), 
                    miu=params['gl_miu'], 
                    return_mid=False, use_anchor=True, 
                    use_balance=True, return_final=False
                )   # sfmx
            else:
                logp = gcn_model(
                    dataset.feats_normed if dataset.feats_normed is not None else dataset.feats, 
                    sparse_dropout(iter_adj_normalized_weighted_gpu, params['gl_gnnr_dropedge_rate_train']),    # inline with the ori version
                    None, 
                    miu=None, 
                    return_mid=False, use_anchor=False, 
                    use_balance=True, return_final=False
                )   # sfmx

        # semi-sup. loss
        semi_loss = F.nll_loss(logp[train_masks], dataset.labels[train_masks].long())
        met_train = calculate_cls_metrics(labels[train_masks].long().cpu().numpy(),
                                          logp[train_masks].detach().cpu().numpy())

        # Total Loss
        if train_gler:
            total_loss : torch.Tensor = semi_loss + params['gl_alpha']* ht_loss + reg_loss
        else:
            total_loss : torch.Tensor = semi_loss

        # update the model by the training loss & clear all the intermediate tensors
        total_loss.backward()

        if train_gler:
            del features_learner, features_anchor, adj_refined_train, logp
        else:
            del logp

        if train_gler:

            optimizer_gler.step()
            optimizer_ht.step()
            optimizer_sim_mlp.step()
            optimizer_mapper.step()

            optimizer_gler.zero_grad(set_to_none=True)
            optimizer_ht.zero_grad(set_to_none=True)
            optimizer_gnnrf.zero_grad(set_to_none=True)
            optimizer_sim_mlp.zero_grad(set_to_none=True)
            optimizer_mapper.zero_grad(set_to_none=True)

            scheduler_gler.step()

            gl_gler_epoch += 1
            gl_curriculum_epoch += 1

        else:

            optimizer_gnnrf.step()

            optimizer_gler.zero_grad(set_to_none=True)
            optimizer_ht.zero_grad(set_to_none=True)
            optimizer_gnnrf.zero_grad(set_to_none=True)
            optimizer_sim_mlp.zero_grad(set_to_none=True)
            optimizer_mapper.zero_grad(set_to_none=True)

            gl_gnnrf_epoch += 1

        # inference & evaluation
        gcn_model.eval()
        ht_model.eval()
        graph_learner.eval()
        sim_mlp.eval()
        hebf_model.eval()

        with torch.no_grad():

            adj_refined_infer = None

            # control the quality of the refined edges
            if train_gler:

                adj_refined_infer = graph_learner_forward(
                                        params['gl_anch_smp_num'], 
                                        selected_anchor_nodes, 
                                        sample_scores_anc, 
                                        sampled_graph, 
                                        full_edge_indices, full_flatten_indices, 
                                        cross_sim, cross_sim_inv, 
                                        inner_sim, edge_onehot_feats, 
                                        inner_homo_feats, node_feats_sim_gcn, 
                                        total_he_feats, 
                                        -1, 
                                        dataset, params, graph_learner, 
                                        sim_mlp, hebf_model, 
                                        mylogger, 
                                        is_train=False
                                    )

                adj_refined_infer = adj_refined_infer.detach()                  # gpu

                pred_anc = row_norm_dense(adj_refined_infer)

                if (1 - params['gl_ht_bootstrap_rate']) and \
                    (params['gl_ht_bootstrap_interval'] == 0 or gl_curriculum_epoch % params['gl_ht_bootstrap_interval'] == 0):
                        anchor_adj = anchor_adj * params['gl_ht_bootstrap_rate'] \
                                   + pred_anc.detach() * (1 - params['gl_ht_bootstrap_rate'])
                        anchor_adj = anchor_adj.detach()        # gpu

                gcn_reps, logp = gcn_model(
                    dataset.feats_normed if dataset.feats_normed is not None else dataset.feats, 
                    ori_adj_normalized_gpu, 
                    adj_refined_infer, 
                    miu=params['gl_miu'], 
                    return_mid=True, use_anchor=True, 
                    use_balance=True, return_final=False
                )   # sfmx

                loss_val = F.nll_loss(logp[val_masks], dataset.labels[val_masks].long())
                met_val = calculate_cls_metrics(labels[val_masks].long().cpu().numpy(),
                                                logp[val_masks].detach().cpu().numpy())

            else:

                if is_R_updated:
                    gcn_reps, logp = gcn_model(
                        dataset.feats_normed if dataset.feats_normed is not None else dataset.feats, 
                        ori_adj_normalized_gpu, 
                        best_adj_refined, 
                        miu=params['gl_miu'], 
                        return_mid=True, use_anchor=True, 
                        use_balance=True, return_final=False
                    )   # sfmx
                else:
                    gcn_reps, logp = gcn_model(
                        dataset.feats_normed if dataset.feats_normed is not None else dataset.feats, 
                        iter_adj_normalized_weighted_gpu,       # inline with the ori version
                        None, 
                        miu=None, 
                        return_mid=True, use_anchor=False, 
                        use_balance=True, return_final=False
                    )   # sfmx

                loss_val = F.nll_loss(logp[val_masks], dataset.labels[val_masks].long())
                met_val = calculate_cls_metrics(labels[val_masks].long().cpu().numpy(),
                                                logp[val_masks].detach().cpu().numpy())

        # update the best model weights
        if met_val > best_met_val:
            mylogger.logger.info("Update! The current best met_val: {:.4f}.".format(met_val))
            bad_counter = 0
            best_epoch = gl_epoch
            best_met_val = met_val
            best_val_logp = logp.detach()
            best_gcn_reps = gcn_reps.detach()
            best_gler_model_weights = deepcopy(graph_learner.state_dict())
            best_gnnrf_model_weights = deepcopy(gcn_model.state_dict())
            best_ht_model_weights = deepcopy(ht_model.state_dict())
            best_sim_mlp_weights = deepcopy(sim_mlp.state_dict())
            if train_gler:
                best_adj_refined = adj_refined_infer.detach()
                is_R_updated = True
            edge_onehot_feats, inner_homo_feats, node_feats_sim_gcn = calculate_PL_feats_anc(
                dataset, split_id, gl_epoch, 
                best_val_logp, best_gcn_reps, 
                best_adj_refined, 
                ori_adj_normalized_gpu, 
                params['gl_anch_smp_num'], 
                selected_anchor_nodes, 
                mylogger
            )
        else:
            bad_counter += 1

        del logp

        if bad_counter >= params['gl_patience']:
            mylogger.logger.info('GLer: Early Stopping!')
            break

        newline = pd.DataFrame({'stage': 'graph_learning_refinement', 
                                'gl_epoch': gl_epoch, 'split_id': split_id, 'single_epoch_time': time.time() - t0, 
                                'train_semi_loss': semi_loss.item(), 'train_ht_loss': ht_loss.item(), 
                                'train_total_loss': total_loss.item(), 
                                'met_train': met_train, 'met_val': met_val, 'loss_val': loss_val.item()}, index=[0])
        train_metrics_df = pd.concat([train_metrics_df, newline], axis=0)

    total_training_time = time.time() - start_time
    mylogger.logger.info('The best GL epoch: {} | The best met_val {:.4f}'.format(best_epoch, best_met_val))
    mylogger.logger.info('Total training time(s): {:.4f}'.format(total_training_time))

    graph_learner.load_state_dict(best_gler_model_weights)
    gcn_model.load_state_dict(best_gnnrf_model_weights)
    ht_model.load_state_dict(best_ht_model_weights)
    sim_mlp.load_state_dict(best_sim_mlp_weights)

    best_adj_refined = best_adj_refined.to(params['device'])

    return best_gnnrf_model_weights, best_met_val, best_val_logp, \
           best_adj_refined, is_R_updated, iter_adj_normalized_weighted_gpu, \
           train_metrics_df


def initial_structure_filtering_sp(
    node_difficulty: torch.Tensor, 
    iter_adj_unnormalized_binary: torch.Tensor, 
    add_self_loop: bool, 
    mylogger: MyLogger
):
    """
    """

    global params

    if params['gsl_init_stru_filter_kept_ratio'] > 0.99:
        return iter_adj_unnormalized_binary

    if not iter_adj_unnormalized_binary.is_sparse:
        mylogger.logger.error("The input adj matrix should be a sparse tensor!")
        sys.exit(1)

    if not iter_adj_unnormalized_binary.is_coalesced():
        iter_adj_unnormalized_binary = iter_adj_unnormalized_binary.coalesce()

    # calculate the sapmle scores
    coo_edge_indices = iter_adj_unnormalized_binary.indices()
    num_init_edges = coo_edge_indices.shape[1]
    num_kept_edges = torch.floor(torch.tensor(params['gsl_init_stru_filter_kept_ratio'], 
                                    dtype=torch.float64, device=params['device'])* num_init_edges).long()  

    difficulty_u = node_difficulty[coo_edge_indices[0]]
    difficulty_v = node_difficulty[coo_edge_indices[1]]

    sample_scores = (1 - difficulty_u) * (1 - difficulty_v)

    del difficulty_u, difficulty_v

    # topk selection
    _, selected_edges = torch.sort(sample_scores, descending=True, stable=True)
    selected_edges = selected_edges[:num_kept_edges]
    del _

    # construct the new adj matrix
    new_edge_indices = coo_edge_indices[:, selected_edges]
    del selected_edges
    new_edge_values = torch.ones(new_edge_indices.shape[1], 
                                 dtype=torch.float32, device=params['device'])

    new_binary_adj = torch.sparse_coo_tensor(new_edge_indices.detach(), 
                                             new_edge_values.detach(), 
                                             dtype=torch.float32, 
                                             size=iter_adj_unnormalized_binary.shape, 
                                             device=params['device'])

    if add_self_loop:
        new_binary_adj = add_remaining_self_loops_torch_sp(new_binary_adj, device=params['device'])

    return new_binary_adj


def darling_forward(
    mylogger: MyLogger, 
    hst_best_met_val_list_st0: list, 
    hst_best_loss_list_st1: list, 
    hst_best_loss_list_st2: list, 
    hst_best_met_val_list_st3: list, 
    hst_val_test_list: list, 
    train_metrics_df_st0: pd.DataFrame, 
    train_metrics_df_st1: pd.DataFrame, 
    train_metrics_df_st2: pd.DataFrame, 
    train_metrics_df_st3: pd.DataFrame, 
    use_repeat_seed: bool=True
):

    global params

    if use_repeat_seed:                            # minesweeper, roman-empire, amazon-ratings (multiple splits)
        n_splits = params['repetition']
        set_seed(params['seed'])                   # all different splits share the same seed (5/1)
        dataset = OpengslDataset(params['dataset'], n_splits=n_splits, 
                                 feat_norm=params['feat_norm'], verbose=True)
    else:                                          # cora, citeseer, pubmed (single split)
        n_splits = 1
        dataset = OpengslDataset(params['dataset'], n_splits=n_splits, 
                                 feat_norm=params['feat_norm'], verbose=True)

    ori_adj_normalized = sym_norm_sp_tensor_tractable(dataset.adj, add_loop=True, 
                                            device=params['device']).coalesce().to('cpu')
    ori_adj_unnormalized = add_self_loops_torch_sp(dataset.adj, device=params['device'])
    ori_adj_unnormalized = ori_adj_unnormalized.to('cpu')      # cpu
    dataset.adj = dataset.adj.to('cpu')

    for rep_id in range(params['repetition']):

        if not use_repeat_seed:                    # cora, citeseer, pubmed (single split)
            rep_seed = params['seed'] + rep_id     # 0: 0, 1, 2, 3, 4
            set_seed(rep_seed)                     # use different seeds for the same split (1/5)
            split_id = 0
        else:                                      # minesweeper, roman-empire, amazon-ratings (multiple splits)
            rep_seed = params['seed']              # already set above
            split_id = rep_id                      # 5: 0, 1, 2, 3, 4

        mylogger.logger.info(star_formatter(f"Rep {rep_id}, Split {split_id}, Seed {rep_seed} Started... ", short=True))

        # pretrain the initial pseudo-labeling model
        mylogger.logger.info(star_formatter("Stage 0 (init): Training the Initial PL Model... ", short=True))

        ori_adj_normalized_gpu = ori_adj_normalized.to(params['device'])
        acc_val_st0, _, best_val_logp, train_metrics_df_st0 = \
            train_pl_model_split(dataset, split_id, ori_adj_normalized_gpu, mylogger, train_metrics_df_st0)

        del ori_adj_normalized_gpu

        hst_best_met_val_list_st0.append(acc_val_st0)

        mylogger.logger.info(star_formatter("Stage 0 (init) Finished!", short=True))

        # define all the models & optimizers
        gcn_model = GCN_Anchor(nfeat=dataset.dim_feats, nhid=params['gl_gnnr_nhid'], nclass=dataset.n_classes, 
                               n_layers=params['gl_gnnr_n_layers'], dropout=params['gl_gnnr_dropout'], 
                               act=params['gl_gnnr_act'], weight_initializer='uniform', 
                               n_linear=1, input_dropout=0, 
                               input_layer=False, output_layer=False, 
                               norm=None, bias=True).to('cpu')

        if params['gl_sim_mlp_type'] == 'diag':
            sim_mlp = MLP_Diag(
                        num_layers=params['gl_sim_mlp_n_layers'], 
                        input_size=dataset.feats.shape[1], 
                        mlp_act=params['gl_sim_mlp_act'], 
                        dropout=params['gl_sim_mlp_dropout'], 
                        Normalization='bn', 
                        InputNorm=False
                    ).to('cpu')          # cora, citeseer (high-dim)
            if params['gl_sim_mlp_act'] == 'F.relu':
                sim_mlp.reset_parameters(mode='relu')
            elif params['gl_sim_mlp_act'] == 'F.tanh':
                sim_mlp.reset_parameters(mode='tanh')
            else:
                raise Exception("MLP_Diag: The activation function is not supported!")
        else:                            # full
            sim_mlp = MLP(
                        in_channels=dataset.feats.shape[1], 
                        hidden_channels=dataset.feats.shape[1], 
                        out_channels=dataset.feats.shape[1], 
                        num_layers=params['gl_sim_mlp_n_layers'], 
                        dropout=params['gl_sim_mlp_dropout'], 
                        Normalization='bn', 
                        InputNorm=False
                    ).to('cpu')          # pubmed & remaining datasets (low-dim)
            sim_mlp.reset_parameters(mode='relu')

        graph_learner = Graph_Learner_Similarity(
                            hidden_channels=params['gl_gler_hidden_channels'], 
                            num_layers=params['gl_gler_n_layers'], 
                            dropout_mlp=params['gl_gler_dropout_mlp'], 
                            ensemble_n_models=params['gl_gler_n_models'], 
                            num_classes=dataset.n_classes
                        ).to('cpu')                 # for mlp node reps & dual implementation

        # model for head-tail loss
        ht_model = Head_Tail_Anc_GNN(
                        gnn_in_channels=dataset.dim_feats, 
                        gnn_hidden_channels=params['gl_ht_gnn_hidden_channels'], 
                        gnn_out_channels=params['gl_ht_gnn_out_channels'], 
                        gnn_num_layers=params['gl_ht_gnn_n_layers'],
                        gnn_dropout=params['gl_ht_gnn_dropout'],
                        proj_hidden_channels=params['gl_ht_proj_n_channels'], 
                        proj_out_channels=params['gl_ht_proj_n_channels'], 
                        proj_num_layers=params['gl_ht_proj_n_layers'], 
                        proj_Normalization='None'
                    ).to('cpu')

        # get the HNN model used in the pretraining phase & HEBF
        hnn_encoder = HyperEncoder_csr(dataset.dim_feats, params['edge_rep_dim'], 
                         params['hnn_encoder_dropout'], params['hnn_encoder_n_layer']).to('cpu')

        # DHG ECL Pretraining
        # perform the contrastive pretraining on DHG
        dhg_ecl_model = DHG_ECL(edge_dim=params['edge_rep_dim'], 
                                proj_dim=params['dhg_ecl_proj_dim']).to('cpu')

        # HGCL: HEBF
        hebf_model = HEBF_csr(
            edge_dim=params['edge_rep_dim'], 
            m=params['hebf_circle_m'], 
            gamma=params['hebf_circle_gamma'],
            temp=params['hebf_circle_temp']
        ).to('cpu')

        # optimizers
        optimizer_gler = torch.optim.Adam(graph_learner.parameters(), 
                    lr=params['gl_gler_lr'], weight_decay=params['gl_gler_weight_decay'])
        eta_min = max(params['gl_gler_lr'] / 500, 1e-7)         # larger than 1e-7
        scheduler_gler = CosineAnnealingWarmRestarts(
            optimizer_gler, T_0=params['gl_gler_n_epochs'], T_mult=1, eta_min=eta_min, 
        )

        optimizer_ht = torch.optim.Adam(ht_model.parameters(), 
                                        lr=params['gl_ht_lr'], 
                                        weight_decay=params['gl_ht_weight_decay'])

        optimizer_gnnrf = torch.optim.Adam(gcn_model.parameters(), 
                                           lr=params['gl_gnnr_lr'], 
                                           weight_decay=params['gl_gnnr_weight_decay'])

        optimizer_sim_mlp = torch.optim.Adam(sim_mlp.parameters(), 
                                             lr=params['gl_sim_mlp_lr'], 
                                             weight_decay=params['gl_sim_mlp_weight_decay'])

        optimizer_ecl = torch.optim.Adam([*hnn_encoder.parameters(), *dhg_ecl_model.parameters()], 
                                    lr=params['dhg_ecl_lr'], weight_decay=params['dhg_ecl_weight_decay'])

        optimizer_hgcl = torch.optim.Adam([*hnn_encoder.parameters(), *hebf_model.parameters()],
                                lr=params['hebf_lr'], weight_decay=params['hebf_weight_decay'])

        iter_adj_unnormalized_binary = ori_adj_unnormalized.to(params['device'], copy=True).detach()        # gpu / cpu
        if not iter_adj_unnormalized_binary.is_coalesced():
            iter_adj_unnormalized_binary = iter_adj_unnormalized_binary.coalesce()
        if not params['gsl_use_init_stru_filter']:
            iter_adj_unnormalized_weighted = ori_adj_unnormalized.to('cpu', copy=True).detach()             # cpu

        hst_best_loss_st1 = 1e9
        hst_best_pos_st2 = 1e9
        hst_best_met_val_st3 = -1

        hst_best_gnnrf_model_weights = None
        hst_best_adj_refined = None

        mylogger.logger.info(star_formatter(f"Rep {rep_id}, Split {split_id}, Seed {rep_seed} Started... ", short=True))

        # use `best_gnnr_weights` & the DMer to get the difficulty scores
        mylogger.logger.info(star_formatter("Stage 0 (iter-1/2): Pseudo-labeling & Difficulty Measuring... ", short=True))

        pseudo_labels, train_metrics_df_st0 = pseudo_labeling_scalar(dataset, split_id, 
                                                      best_val_logp, mylogger, train_metrics_df_st0)

        node_difficulty, _, _ = difficulty_measurer_rank_tractable_hp_deg(pseudo_labels, iter_adj_unnormalized_binary, params)

        del pseudo_labels, _

        if params['gsl_use_init_stru_filter']:
            mylogger.logger.info(star_formatter("Stage 0 (iter-2/2): Initial Structure Filtering... ", short=True))

            mylogger.logger.info("# of initial edges: {}".format(iter_adj_unnormalized_binary.indices().shape[1]))

            # get the initial structure filtering results
            iter_adj_unnormalized_binary = initial_structure_filtering_sp(
                                                node_difficulty, 
                                                iter_adj_unnormalized_binary, 
                                                add_self_loop=True, 
                                                mylogger=mylogger
                                           ).coalesce()

            mylogger.logger.info("# of remaining edges: {}".format(iter_adj_unnormalized_binary.indices().shape[1]))

            iter_adj_unnormalized_weighted = iter_adj_unnormalized_binary.to('cpu', copy=True).detach()     # cpu

        mylogger.logger.info(star_formatter("Stage 0 (iter) Finished!", short=True))

        mylogger.logger.info(star_formatter("Stage 1: Contrastive Pretraining for HNN... ", short=True))

        # Use DHT to transform the original graph to the dual hypergraph
        # get the index of the edges in the lower triangle of the adjacency matrix
        if not iter_adj_unnormalized_binary.is_coalesced():
            iter_adj_unnormalized_binary = iter_adj_unnormalized_binary.coalesce()
        lower_tri_idx = iter_adj_unnormalized_binary.indices()[0] >= iter_adj_unnormalized_binary.indices()[1]
        lower_tri_idx = iter_adj_unnormalized_binary.indices()[:, lower_tri_idx]

        num_normal_he_dhg = iter_adj_unnormalized_binary.shape[1]

        # move the `iter_adj_normalized` to the cpu to save the gpu memory
        iter_adj_unnormalized_binary = iter_adj_unnormalized_binary.to('cpu')

        # keep the edge_id used in the dual hypergraph *continuous* & save the mapping
        edge_id_local = torch.arange(lower_tri_idx.shape[-1], device=params['device'], dtype=torch.long)

        # transform `lower_tri_idx` to the E-HE indices of the dual hypergraph
        # col: [edge, hyperedge].T
        dhg_index = torch.cat([edge_id_local.repeat_interleave(2).view(1, -1), 
                                   lower_tri_idx.T.reshape(1, -1)], dim=0)

        num_edge_dhg = edge_id_local.shape[0]

        # add self-loops to every node in the dual hypergraph
        num_all_he_dhg = num_normal_he_dhg + num_edge_dhg
        loops = torch.cat([edge_id_local.view(1, -1), 
                           torch.arange(num_normal_he_dhg, num_all_he_dhg, 1, 
                                        device=params['device']).view(1, -1)], dim=0)

        del edge_id_local

        dhg_index = torch.cat([dhg_index, loops], dim=1).long()

        del loops

        # sort `dhg_index` by the hyperedge index (for HyperEncoder & hypeboy)
        _, col_idx = torch.sort(dhg_index[1], descending=False, stable=True)
        dhg_index = dhg_index[:, col_idx]

        del col_idx, _

        feats = dataset.feats.detach()
        edge_feats = (feats[lower_tri_idx[0]] + feats[lower_tri_idx[1]]) / 2.0

        hnn_encoder = hnn_encoder.to(params['device'])
        hnn_encoder.reset_parameters()

        dhg_ecl_model = dhg_ecl_model.to(params['device'])
        dhg_ecl_model.reset_parameters()
        best_hnn_encoder_weights, loss_st1, train_metrics_df_st1 = dhg_ecl_pretraining( 
            mylogger, train_metrics_df_st1, num_all_he_dhg, hnn_encoder, 
            dhg_ecl_model, optimizer_ecl, edge_feats, dhg_index
        )

        if loss_st1 < hst_best_loss_st1:
            hst_best_loss_st1 = loss_st1

        dhg_ecl_model = dhg_ecl_model.to('cpu')

        hnn_encoder.load_state_dict(best_hnn_encoder_weights)

        edge_feats = edge_feats.to('cpu').pin_memory()

        mylogger.logger.info(star_formatter("Stage 1 Finished!", short=True))

        mylogger.logger.info(star_formatter("Stage 2: HEBF & HECL... ", short=True))

        hebf_model = hebf_model.to(params['device'])
        hebf_model.reset_parameters()

        best_hnn_encoder_weights, best_hebf_model_weights, totalHE_wto_loops, \
            he_size_wto_loops, pos_st2, train_metrics_df_st2 = \
                hebf_training(mylogger, train_metrics_df_st2, 
                    hnn_encoder, hebf_model, optimizer_hgcl, edge_feats, dhg_index, num_all_he_dhg
                )

        if pos_st2 > hst_best_pos_st2:
            hst_best_pos_st2 = pos_st2

        mylogger.logger.info(star_formatter("Stage 2 Finished!", short=True))

        mylogger.logger.info(star_formatter("Stage 3: Graph Learning & Refinement... ", short=True))

        # load the best weights of the HNN model
        hnn_encoder.load_state_dict(best_hnn_encoder_weights)
        hebf_model.load_state_dict(best_hebf_model_weights)

        ht_model = ht_model.to(params['device'])
        graph_learner = graph_learner.to(params['device'])
        gcn_model = gcn_model.to(params['device'])
        sim_mlp = sim_mlp.to(params['device'])

        total_edge_feats = edge_feats.to(params['device']).detach()        # a copy on gpu

        # get the edge representations
        hnn_encoder.eval()
        with torch.no_grad():
            total_edge_feats : torch.Tensor = hnn_encoder(total_edge_feats, dhg_index, num_all_he_dhg)
        hnn_encoder = hnn_encoder.to('cpu')

        # get the hyperedge features for the training edges
        dhg_index_without_loops = dhg_index[:, :2* lower_tri_idx.shape[-1]]     # wto loops *on the Hypergraph*
        del dhg_index
        del lower_tri_idx
        with torch.no_grad():
            total_he_feats : torch.Tensor = \
                HEBF_csr.mean_he_feat_layer(total_edge_feats, dhg_index_without_loops, is_sorted=True)
        del dhg_index_without_loops
        total_edge_feats = total_edge_feats.detach().to('cpu').pin_memory()

        hebf_model.eval()

        total_he_feats = total_he_feats.detach().to('cpu').pin_memory()

        best_gnnr_weights, best_val_met_st3, best_val_logp, \
            best_adj_refined, is_R_updated, iter_adj_normalized_weighted_gpu, \
            train_metrics_df_st3 = \
            graph_learning_refinement(dataset, split_id, mylogger, 
                train_metrics_df_st3, graph_learner, gcn_model, sim_mlp, 
                ht_model, hebf_model, optimizer_gler, scheduler_gler, 
                optimizer_ht, optimizer_gnnrf, optimizer_sim_mlp, 
                total_edge_feats, total_he_feats, 
                ori_adj_normalized, iter_adj_unnormalized_weighted, 
                node_difficulty, totalHE_wto_loops, he_size_wto_loops)

        ht_model = ht_model.to('cpu')
        graph_learner = graph_learner.to('cpu')
        gcn_model = gcn_model.to('cpu')

        mylogger.logger.info(star_formatter("Stage 3 Finished!", short=True))

        if best_val_met_st3 > hst_best_met_val_st3:
            hst_best_met_val_st3 = best_val_met_st3
            hst_best_gnnrf_model_weights = best_gnnr_weights
            hst_best_adj_refined : torch.Tensor = best_adj_refined      # cpu & unnormalized

        # save the training metrics of this split
        hst_best_loss_list_st1.append(hst_best_loss_st1)
        hst_best_loss_list_st2.append(hst_best_pos_st2)
        hst_best_met_val_list_st3.append(hst_best_met_val_st3)

        # evaluate the model on the test set
        mylogger.logger.info(star_formatter("Evaluating the Model on the Test Set... ", short=True))
        test_masks = dataset.test_masks[split_id]
        labels = dataset.labels
        gcn_model = gcn_model.to(params['device'])
        gcn_model.load_state_dict(hst_best_gnnrf_model_weights)
        gcn_model.eval()
        with torch.no_grad():
            # keep the test procedure the same as the one in the GLer validation phase
            if is_R_updated:
                hst_best_adj_refined = hst_best_adj_refined.to(params['device']).detach()
                ori_adj_normalized_gpu = ori_adj_normalized.to(params['device'])              # a sparse mx
                logp = gcn_model(
                    dataset.feats_normed if dataset.feats_normed is not None else dataset.feats, 
                    ori_adj_normalized_gpu, 
                    hst_best_adj_refined, 
                    miu=params['gl_miu'], 
                    return_mid=False, use_anchor=True, 
                    use_balance=True, return_final=False
                )   # sfmx
                del ori_adj_normalized_gpu
            else:
                logp = gcn_model(
                    dataset.feats_normed if dataset.feats_normed is not None else dataset.feats, 
                    iter_adj_normalized_weighted_gpu,       # inline with the ori version
                    None, 
                    miu=None, 
                    return_mid=False, use_anchor=False, 
                    use_balance=True, return_final=False
                )   # sfmx

            loss_test = F.nll_loss(logp[test_masks], labels[test_masks].long())
            met_test = calculate_cls_metrics(labels[test_masks].long().cpu().numpy(),
                                             logp[test_masks].detach().cpu().numpy())

        mylogger.logger.info(f"Loss on the Test Set: {loss_test.item()}, Met on the Test Set: {met_test}.")
        hst_val_test_list.append(met_test)

        del hst_best_adj_refined, logp

        mylogger.logger.info(star_formatter(f"Rep {rep_id}, Split {split_id}, Seed {rep_seed} Finished!", short=False))

    return train_metrics_df_st0, train_metrics_df_st1, train_metrics_df_st2, train_metrics_df_st3


def start_training():

    global params

    exp_id = params['expid']

    mylogger = MyLogger(log_dir=params['log_dir'], exp_id=exp_id, trial_id=0, params=params, 
                                model_name='DarlingGSL', task_name='NCLS')
    mylogger.logger.info(get_separator())
    mylogger.logger.warning(warning_str)
    mylogger.logger.info(get_separator())
    mylogger.logger.info(f'Current time: {time.strftime("%m-%d-%Y-%H-%M-%S", time.localtime())}')
    mylogger.logger.info(f'Experiment ID: {exp_id}')
    mylogger.logger.info(f'Settings & Hyperparameters (probably after correction): {params}')

    # record the training metrics of the 4 stages
    train_metrics_df_st0 = pd.DataFrame(columns=['stage', 'split_id', 'pl_epoch', 
                                                 'single_epoch_time', 'loss_train', 
                                                 'met_train', 'loss_val', 'met_val'])

    train_metrics_df_st1 = pd.DataFrame(columns=['stage', 'dhg_ecl_epoch', 
                                                 'single_epoch_time', 'loss'])

    train_metrics_df_st2 = pd.DataFrame(columns=['stage', 'hebf_epoch', 
                                                 'single_epoch_time', 'hebf_loss'])

    train_metrics_df_st3 = pd.DataFrame(columns=['stage', 'gl_epoch', 
                                                 'split_id', 'single_epoch_time', 
                                                 'train_semi_loss', 'train_ht_loss', 
                                                 'train_total_loss', 'met_train', 'met_val', 'loss_val'])

    hst_best_met_val_list_st0 = []
    hst_best_loss_list_st1 = []
    hst_best_loss_list_st2 = []
    hst_best_met_val_list_st3 = []

    hst_val_test_list = []

    if params['dataset'] in ['minesweeper', 'roman-empire', 'amazon-ratings']:
        train_metrics_df_st0, train_metrics_df_st1, train_metrics_df_st2, train_metrics_df_st3 = \
            darling_forward(
                mylogger, 
                hst_best_met_val_list_st0, 
                hst_best_loss_list_st1, 
                hst_best_loss_list_st2, 
                hst_best_met_val_list_st3, 
                hst_val_test_list, 
                train_metrics_df_st0, 
                train_metrics_df_st1, 
                train_metrics_df_st2, 
                train_metrics_df_st3, 
                use_repeat_seed=True
            )
    elif params['dataset'] in ['cora', 'citeseer', 'pubmed']:
        # all the splits are the same & set different seeds for different splits
        train_metrics_df_st0, train_metrics_df_st1, train_metrics_df_st2, train_metrics_df_st3 = \
            darling_forward(
                mylogger, 
                hst_best_met_val_list_st0, 
                hst_best_loss_list_st1, 
                hst_best_loss_list_st2, 
                hst_best_met_val_list_st3, 
                hst_val_test_list, 
                train_metrics_df_st0, 
                train_metrics_df_st1, 
                train_metrics_df_st2, 
                train_metrics_df_st3, 
                use_repeat_seed=False
            )
    else:
        raise Exception(f"Unknown dataset: {params['dataset']}")

    # calculate the mean & std of the test performance
    mylogger.logger.info(star_formatter('Final Results:', short=False))
    mylogger.logger.info(f'Mean test performance: {np.mean(hst_val_test_list)}')
    mylogger.logger.info(f'Std test performance: {np.std(hst_val_test_list)}')

    mylogger.logger.info(get_separator())

    # save the training metrics
    train_metrics_df_st0 = train_metrics_df_st0.reset_index(drop=True)
    train_metrics_df_st1 = train_metrics_df_st1.reset_index(drop=True)
    train_metrics_df_st2 = train_metrics_df_st2.reset_index(drop=True)
    train_metrics_df_st3 = train_metrics_df_st3.reset_index(drop=True)
    train_metrics_df_st0.to_csv(mylogger.filename[:-4] + '_train_metrics_st0.csv', index=False)
    train_metrics_df_st1.to_csv(mylogger.filename[:-4] + '_train_metrics_st1.csv', index=False)
    train_metrics_df_st2.to_csv(mylogger.filename[:-4] + '_train_metrics_st2.csv', index=False)
    train_metrics_df_st3.to_csv(mylogger.filename[:-4] + '_train_metrics_st3.csv', index=False)


if __name__ == '__main__':

    start_training()


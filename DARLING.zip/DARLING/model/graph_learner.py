import torch
import torch.nn as nn

from model.gnns import MLP

import gc






class Graph_Learner_Similarity_Less_Ens(nn.Module):

    def __init__(self, 
        hidden_channels: int, 
        num_layers: int, 
        dropout_mlp: float, 
        ensemble_n_models: int, 
        num_classes: int
    ):

        super(Graph_Learner_Similarity_Less_Ens, self).__init__()

        self.hidden_channels = hidden_channels
        self.num_layers = num_layers
        self.dropout_mlp = dropout_mlp
        self.ensemble_n_models = ensemble_n_models
        self.num_classes = num_classes

        self.model_list = nn.ModuleList([
            MLP(in_channels=9+self.num_classes, hidden_channels=self.hidden_channels, out_channels=1, 
                num_layers=self.num_layers, dropout=self.dropout_mlp, 
                Normalization='bn', InputNorm=False) for _ in range(self.ensemble_n_models)
        ])
        for model in self.model_list:
            model.reset_parameters('tanh')

    def forward(self, 
                node_feats_sim_gcn: torch.Tensor, 
                node_feats_sim_mlp: torch.Tensor, 
                inner_homo_feats: torch.Tensor, 
                inner_sim: torch.Tensor, 
                cross_sim: torch.Tensor, 
                cross_sim_inv: torch.Tensor,  
                he_feats_sim: torch.Tensor, 
                edge_onehot_feats: torch.Tensor, 
                edge_indices: torch.Tensor, 
                full_flatten_indices: torch.Tensor, 
                n_nodes: int, is_train: bool, 
                selected_anchor_nodes: torch.Tensor=None, 
                is_anchor: bool=False):

        """
        """

        cm_shape = cross_sim.shape
        assert cross_sim_inv.shape == cm_shape, "The shape of the input tensor is incorrect!"
        assert inner_sim.shape[1] == 2 and inner_sim.shape[0] == cm_shape[0], "The shape of the input tensor is incorrect!"
        assert is_anchor is False or selected_anchor_nodes is not None, "The selected anchor nodes should be provided!"

        if not is_train:            # full inference

            assert full_flatten_indices is not None, "The full flatten indices should be provided!"

            if not is_anchor:
                x = torch.cat([
                    node_feats_sim_gcn[edge_indices[0], edge_indices[1]].unsqueeze(-1),         # # of channels: 1
                    node_feats_sim_mlp[edge_indices[0], edge_indices[1]].unsqueeze(-1),         # # of channels: 1
                    inner_homo_feats[edge_indices[0]],                                          # # of channels: 1
                    inner_homo_feats[edge_indices[1]],                                          # # of channels: 1 
                    inner_sim[full_flatten_indices, 0].unsqueeze(-1),                           # # of channels: 1
                    inner_sim[full_flatten_indices, 1].unsqueeze(-1),                           # # of channels: 1
                    cross_sim[full_flatten_indices, :],                                         # # of channels: 1
                    cross_sim_inv[full_flatten_indices, :],                                     # # of channels: 1
                    he_feats_sim[edge_indices[0], edge_indices[1]].unsqueeze(-1),               # # of channels: 1
                    edge_onehot_feats[full_flatten_indices, :]                                  # # of channels: |C|
                ], dim=1)
            else:
                x = torch.cat([
                    node_feats_sim_gcn[edge_indices[0], edge_indices[1]].unsqueeze(-1),         # # of channels: 1
                    node_feats_sim_mlp[edge_indices[0], edge_indices[1]].unsqueeze(-1),         # # of channels: 1
                    inner_homo_feats[edge_indices[0]],                                          # # of channels: 1
                    inner_homo_feats[selected_anchor_nodes[edge_indices[1]]],                   # # of channels: 1
                    inner_sim[full_flatten_indices, 0].unsqueeze(-1),                           # # of channels: 1
                    inner_sim[full_flatten_indices, 1].unsqueeze(-1),                           # # of channels: 1
                    cross_sim[full_flatten_indices, :],                                         # # of channels: 1
                    cross_sim_inv[full_flatten_indices, :],                                     # # of channels: 1
                    he_feats_sim[edge_indices[0], edge_indices[1]].unsqueeze(-1),               # # of channels: 1
                    edge_onehot_feats[full_flatten_indices, :]                                  # # of channels: |C|
                ], dim=1)

        else:                       # training: curriculum learning

            assert edge_indices is not None, "The curriculum node pair indices should be provided!"
            assert full_flatten_indices is None, "The full flatten indices should not be provided!"

            with torch.no_grad():
                edge_indices = edge_indices.detach()
                part_flatten_indices = edge_indices[0] * n_nodes + edge_indices[1]
                part_flatten_indices = part_flatten_indices.detach()

            if not is_anchor:
                x = torch.cat([
                    node_feats_sim_gcn[edge_indices[0], edge_indices[1]].unsqueeze(-1),         # # of channels: 1
                    node_feats_sim_mlp[edge_indices[0], edge_indices[1]].unsqueeze(-1),         # # of channels: 1
                    inner_homo_feats[edge_indices[0]],                                          # # of channels: 1
                    inner_homo_feats[edge_indices[1]],                                          # # of channels: 1 
                    inner_sim[part_flatten_indices, 0].unsqueeze(-1),                           # # of channels: 1
                    inner_sim[part_flatten_indices, 1].unsqueeze(-1),                           # # of channels: 1
                    cross_sim[part_flatten_indices, :],                                         # # of channels: 1
                    cross_sim_inv[part_flatten_indices, :],                                     # # of channels: 1
                    he_feats_sim[edge_indices[0], edge_indices[1]].unsqueeze(-1),               # # of channels: 1
                    edge_onehot_feats[part_flatten_indices, :]                                  # # of channels: |C|
                ], dim=1)
            else:
                x = torch.cat([
                    node_feats_sim_gcn[edge_indices[0], edge_indices[1]].unsqueeze(-1),         # # of channels: 1
                    node_feats_sim_mlp[edge_indices[0], edge_indices[1]].unsqueeze(-1),         # # of channels: 1
                    inner_homo_feats[edge_indices[0]],                                          # # of channels: 1
                    inner_homo_feats[selected_anchor_nodes[edge_indices[1]]],                   # # of channels: 1
                    inner_sim[part_flatten_indices, 0].unsqueeze(-1),                           # # of channels: 1
                    inner_sim[part_flatten_indices, 1].unsqueeze(-1),                           # # of channels: 1
                    cross_sim[part_flatten_indices, :],                                         # # of channels: 1
                    cross_sim_inv[part_flatten_indices, :],                                     # # of channels: 1
                    he_feats_sim[edge_indices[0], edge_indices[1]].unsqueeze(-1),               # # of channels: 1
                    edge_onehot_feats[part_flatten_indices, :]                                  # # of channels: |C|
                ], dim=1)

        res = None

        for model in self.model_list:
            z = model(x)
            z = 1 + torch.tanh(z)
            res = z if res is None else res + z
            torch.cuda.empty_cache()

        return res / self.ensemble_n_models


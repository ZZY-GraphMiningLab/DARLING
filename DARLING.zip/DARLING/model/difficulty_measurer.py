import torch

from utils.constants import VERY_SMALL_NUMBER
from utils.common_ops import safe_divide, floor_to_nonzero
from math import floor




def difficulty_measurer_rank_tractable_hp_deg(labels, unnormalized_adj, params):
    """
    """

    from torch_sparse.index_select import index_select
    from torch_sparse.tensor import SparseTensor

    labels = labels.to(params['device']).long()
    unnormalized_adj = unnormalized_adj.to(params['device'], dtype=torch.float32)

    nclasses = torch.unique(labels).shape[0]
    labels_onehot_mx = torch.eye(nclasses, dtype=torch.float32, 
                                        device=params['device'])[labels]

    DEG = torch.sparse.sum(unnormalized_adj, dim=1).long().to_dense()

    DEG_inter_class_dict = {}
    DEG_idx_class_for_P = {}
    for class_idx in range(nclasses):
        DEG_inner_class_dict = {}

        DEG_class_idx_bool = (labels == class_idx)

        # 1. get the index of elements which belong to the class
        # local (array idx) -> global (array value, node idx)
        DEG_class_idx_map = torch.nonzero(DEG_class_idx_bool, as_tuple=False).squeeze()

        DEG_class_idx_sorted, DEG_class_idx_local_idx = torch.sort(DEG[DEG_class_idx_bool], descending=False, stable=True)

        # 2. sort all the nodes by their degree within the class
        DEG_class_idx_global_idx = DEG_class_idx_map[DEG_class_idx_local_idx]

        # 3. get all the unique degree values in the class
        DEG_class_idx_sorted_unique, DEG_class_idx_sorted_counts = torch.unique_consecutive(
                                                            DEG_class_idx_sorted, return_counts=True)

        # 4. get the percentile rank of each unique degree in the class
        temp_idx = 0
        DEG_class_idx_sorted_incls_indices = []
        for count in DEG_class_idx_sorted_counts:
            DEG_class_idx_sorted_incls_indices.append(temp_idx)
            temp_idx += count.item()
        DEG_class_idx_sorted_incls_indices = torch.tensor(DEG_class_idx_sorted_incls_indices, dtype=torch.float32, 
                                                                          device=params['device'])
        DEG_class_idx_sorted_percentile = DEG_class_idx_sorted_incls_indices / \
                                                                DEG_class_idx_sorted.shape[0]

        # 5. construct the lookup table for the percentile rank on the cpu
        DEG_class_idx_sorted_unique = DEG_class_idx_sorted_unique.cpu().numpy()
        DEG_class_idx_sorted_percentile = DEG_class_idx_sorted_percentile.cpu().numpy()

        former_percentile = -1
        best_percentile = -1
        for value, percentile in zip(DEG_class_idx_sorted_unique, DEG_class_idx_sorted_percentile):
            DEG_inner_class_dict[value] = percentile            # (degree, percentile)

            # record the optimal degree theshold for each class
            # dmer_delta = 0.2
            if (best_percentile < 0) or (percentile - former_percentile 
                                                      > params['dmer_delta']):
                best_percentile = percentile
            former_percentile = percentile

        # fix: prevent the corner case that the best percentile is 1.0, which causes no nodes been selected
        if best_percentile >= 0.9999:
            best_percentile = 0.9999

        DEG_inter_class_dict[class_idx] = DEG_inner_class_dict

        # 6. get the nodes with large degree within each class
        DEG_idx_class_for_P[class_idx] = DEG_class_idx_global_idx[floor(best_percentile * DEG_class_idx_global_idx.shape[0]):]

    # use the lookup table to get the percentile rank of each node
    DEG_percentile = torch.tensor([DEG_inter_class_dict[labels[i].item()][DEG[i].item()]
                                        for i in range(DEG.shape[0])], dtype=torch.float32, device=params['device'])

    # 1. get the neighborhood label distribution matrix: C = A* L
    # each row of `C` is the label distribution of the corresponding node
    C = torch.sparse.mm(unnormalized_adj, labels_onehot_mx)

    # 2. normalize the rows of `C`
    C = safe_divide(C, C.sum(dim=1, keepdim=True).expand_as(C))

    # 3. get the index of nodes with large degree within each class
    DEG_idx_class_for_P = torch.cat([DEG_idx_class_for_P[cls] for cls in range(nclasses)], dim=0)

    # 4. calculate the label distribution of each class prototype
    # each row of `P` is the label distribution of the corresponding class prototype
    # rule out the nodes with small degree for prototype's robustness
    labels_onehot_mx_for_P = labels_onehot_mx[DEG_idx_class_for_P]

    unnormalized_adj = SparseTensor.from_torch_sparse_coo_tensor(unnormalized_adj)
    unnormalized_adj_for_P = index_select(unnormalized_adj, 0, DEG_idx_class_for_P)
    unnormalized_adj_for_P = index_select(unnormalized_adj_for_P, 1, DEG_idx_class_for_P)
    unnormalized_adj_for_P = unnormalized_adj_for_P.to_torch_sparse_coo_tensor()
    unnormalized_adj = unnormalized_adj.to_torch_sparse_coo_tensor()

    C_for_P = torch.sparse.mm(unnormalized_adj_for_P, labels_onehot_mx_for_P)
    C_for_P = safe_divide(C_for_P, C_for_P.sum(dim=1, keepdim=True).expand_as(C_for_P))

    P = labels_onehot_mx_for_P.t() @ C_for_P
    P = safe_divide(P, P.sum(dim=1, keepdim=True).expand_as(P))

    # 5. calculate the deviation of each node from its class prototype
    DEV = C - torch.mm(labels_onehot_mx, P)
    DEV = DEV.pow(2).sum(dim=1)

    # group & sort all the nodes by their classes on the cpu
    DEV_inter_class_dict = {}
    for class_idx in range(nclasses):
        DEV_inner_class_dict = {}
        DEV_class_idx_sorted, _ = torch.sort(DEV[labels == class_idx], descending=False, stable=True)

        # get the percentile rank of each unique deviation in the class
        # https://discuss.pytorch.org/t/unique-function-for-float-tensors/105989
        explvl = torch.tensor([28], device=params['device'])           # threshold 1/(2**28) ~= 1e-9
        DEV_class_idx_sorted = DEV_class_idx_sorted.ldexp(explvl).trunc().long()  # encode
        DEV_class_idx_sorted_unique, DEV_class_idx_sorted_counts = torch.unique_consecutive(
                                                            DEV_class_idx_sorted, return_counts=True)
        temp_idx = 0
        DEV_class_idx_sorted_incls_indices = []
        for count in DEV_class_idx_sorted_counts:
            DEV_class_idx_sorted_incls_indices.append(temp_idx)
            temp_idx += count.item()

        DEV_class_idx_sorted_incls_indices = torch.tensor(DEV_class_idx_sorted_incls_indices, dtype=torch.float32,
                                                                          device=params['device'])
        DEV_class_idx_sorted_percentile = DEV_class_idx_sorted_incls_indices / \
                                                        DEV_class_idx_sorted.shape[0]

        # construct the lookup table for the percentile rank on the cpu
        DEV_class_idx_sorted_unique = DEV_class_idx_sorted_unique.cpu().numpy()
        DEV_class_idx_sorted_percentile = DEV_class_idx_sorted_percentile.cpu().numpy()

        for value, percentile in zip(DEV_class_idx_sorted_unique, DEV_class_idx_sorted_percentile):
            DEV_inner_class_dict[value] = percentile

        DEV_inter_class_dict[class_idx] = DEV_inner_class_dict

    # use the lookup table to get the percentile rank of each node
    DEV = DEV.ldexp(explvl).trunc().long()
    DEV_percentile = torch.tensor([DEV_inter_class_dict[labels[i].item()][DEV[i].item()]
                                    for i in range(DEV.shape[0])], dtype=torch.float32, device=params['device'])

    # calculate the difficulty of each node
    difficulty_dev = DEV_percentile
    difficulty_deg = 1 - DEG_percentile

    difficulty = params['dmer_omega'] * difficulty_dev + (1 - params['dmer_omega']) * difficulty_deg

    return difficulty.detach(), difficulty_dev.detach(), difficulty_deg.detach()


import time

import torch
import torch.nn as nn
import torch.nn.functional as F

from torch_geometric.nn.dense.linear import Linear

from torch_geometric.nn.conv import MessagePassing
from torch_scatter import segment_csr
from torch_sparse import SparseTensor, matmul

import math
import numpy as np




"""
Credits:

    OpenGSL: https://github.com/OpenGSL/OpenGSL
    
    UniGCNII: https://github.com/OneForward/UniGNN
"""




"""
The GCN code is borrowed from the `OpenGSL` library. The original code is modified to fix the following issue: 

FIX: correct the message passing approach in OpenGSL library to speed up the training process.

FIX: stability & reproducibility of the message passing approach.
"""

class GraphConvolutionDiagLayer(nn.Module):
    '''
    A GCN convolution layer of diagonal matrix multiplication
    '''
    def __init__(self, input_size):
        super(GraphConvolutionDiagLayer, self).__init__()

        self.input_size = input_size

        self.weights = nn.Parameter(torch.Tensor(1, self.input_size))

        self.reset_parameters('ones')

    def reset_parameters(self, mode='ones'):
        if mode == 'sigmoid':
            torch.nn.init.xavier_uniform_(self.weights)
        elif mode == 'relu':
            torch.nn.init.kaiming_uniform_(self.weights, nonlinearity='relu', mode='fan_in')
        elif mode == 'ones':       # *** ones (for input feature transformation)
            torch.nn.init.ones_(self.weights)
        else:
            raise Exception('`GraphConvolutionDiagLayer`: Invalid mode!')

    def forward(self, x: torch.Tensor, adj: torch.Tensor):

        assert isinstance(adj, torch.Tensor) , "`GraphConvolutionLayer`: `adj` must be a `torch.Tensor`!"
        assert x.is_sparse is False, "`GraphConvolutionLayer`: `x` must be a dense tensor!"

        x = torch.einsum('ij,...j->ij', x, self.weights)

        # Message passing (supports both dense and sparse adj)
        if adj.is_sparse:
            x = matmul(SparseTensor.from_torch_sparse_coo_tensor(adj), x)       # FIX: stability & reproducibility
        else:
            x = torch.mm(adj, x)

        return x


class GCNDiagEncoder(nn.Module):
    '''
    Encoder used in `"Graph-Revised Convolutional Network" <https://arxiv.org/abs/1911.07123>`_ paper.
    '''
    def __init__(self, n_layers, d, activation='F.tanh'):
        super(GCNDiagEncoder, self).__init__()
        self.layers = nn.ModuleList()
        for _ in range(n_layers):
            self.layers.append(GraphConvolutionDiagLayer(d))
        self.activation = eval(activation)

        self.reset_parameters('ones')

    def reset_parameters(self, mode='ones'):
        for lyer in self.layers:
            lyer.reset_parameters(mode)

    def forward(self, x, adj):

        for i, layer in enumerate(self.layers):
            x = layer(x, adj)
            if i != (len(self.layers) - 1):
                x = self.activation(x)
        return x


class GraphConvolutionLayer(nn.Module):

    def __init__(self, in_features, out_features, dropout=0.5, n_linear=1, bias=True, act='F.relu',
                 last_layer=False, weight_initializer=None, bias_initializer=None):
        super(GraphConvolutionLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.mlp = nn.ModuleList()
        self.mlp.append(Linear(in_features, out_features, bias=bias, weight_initializer=weight_initializer, bias_initializer=bias_initializer))
        for i in range(n_linear-1):
            self.mlp.append(Linear(out_features, out_features, bias=bias, weight_initializer=weight_initializer, bias_initializer=bias_initializer))
        self.dropout = dropout
        self.act = eval(act)
        self.last_layer = last_layer

    def forward(self, x: torch.Tensor, adj: torch.Tensor):
        """ 
        Graph Convolutional Layer forward function.add()

        FIX: correct the message passing approach in OpenGSL library to speed up the training process.
        """

        assert isinstance(adj, torch.Tensor) , "`GraphConvolutionLayer`: `adj` must be a `torch.Tensor`!"
        assert x.is_sparse is False, "`GraphConvolutionLayer`: `x` must be a dense tensor!"

        x = self.mlp[0](x)                  # FIX：create the message first, then pass the message
        for i in range(1, len(self.mlp)):
            x = self.mlp[i](x)
            x = self.act(x)
            x = F.dropout(x, p=self.dropout, training=self.training)

        # Message passing (supports both dense and sparse adj)
        if adj.is_sparse:
            x = matmul(SparseTensor.from_torch_sparse_coo_tensor(adj), x)       # FIX: stability & reproducibility
        else:
            x = torch.mm(adj, x)

        if not self.last_layer:
            x = self.act(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        return x

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


class GCNEncoder(nn.Module):
    '''
    GCN encoder.

    Parameters
    ----------
    nfeat : int
        Dimensions of input features.
    nhid : int
        Dimensions of hidden representations.
    nclass : int
        Dimensions of output representations.
    n_layers : int
        Number of layers.
    dropout : float
        Dropout rate.
    input_dropout : float
        Dropout rate on the infut at first. Only used when `input_layer` is `True`.
    norm : str
        Specify batchnorm or layernorm. The operation won't be done if set to `None`.
    n_linear : int
        Number of linear layers in a GCN layer.
    act : str
        Specify the activation function used.
    input_layer : bool
        Whether to set a seperate linear layer for input.
    output_layer: bool
        Whether to set a seperate linear layer for output.
    weight_initializer: str
        Specify the way to initialize the weights.
    bias_initializer: str
        Specify the way to initialize the bias.
    bias : bool
        Whether to add bias to linear transform in GCN.
    '''
    def __init__(self, nfeat, nhid, nclass, n_layers=2, dropout=0.5, input_dropout=0.0, norm=None, n_linear=1,
                 act='F.relu', input_layer=False, output_layer=False, weight_initializer=None,
                 bias_initializer=None, bias=True):

        super(GCNEncoder, self).__init__()

        self.nfeat = nfeat
        self.nclass = nclass
        self.n_layers = n_layers
        self.input_layer = input_layer
        self.output_layer = output_layer
        self.n_linear = n_linear
        self.norm = norm
        if norm:
            self.norm_type = eval('nn.'+norm['norm_type'])
        self.act = eval(act)
        if input_layer:
            self.input_linear = nn.Linear(in_features=nfeat, out_features=nhid)
            self.input_drop = nn.Dropout(input_dropout)
        if output_layer:
            self.output_linear = nn.Linear(in_features=nhid, out_features=nclass)
            self.output_normalization = self.norm_type(nhid)
        self.convs = nn.ModuleList()
        if self.norm:
            self.norms = nn.ModuleList()
        else:
            self.norms = None

        for i in range(n_layers):
            if i == 0 and not self.input_layer:
                in_hidden = nfeat
            else:
                in_hidden = nhid
            if i == n_layers - 1 and not self.output_layer:
                out_hidden = nclass
            else:
                out_hidden = nhid

            self.convs.append(GraphConvolutionLayer(in_hidden, out_hidden, dropout, n_linear, act=act,
                                                    weight_initializer=weight_initializer, bias_initializer=bias_initializer,
                                                    bias=bias))
            if self.norm:
                self.norms.append(self.norm_type(in_hidden))
        self.convs[-1].last_layer = True

    def forward(self, x, adj, return_mid=False):
        '''
        Parameters
        ----------
        x : torch.tensor
            Input features.
        adj : torch.tensor
            Input adj.
        return_mid : bool
            Whether to return hidden representations.
        Returns
        -------
        x : torch.tensor
            Encoded features.
        mid : torch.tensor
            hidden representations. Returned when `return_mid` is True.

        '''
        if self.input_layer:
            x = self.input_linear(x)
            x = self.act(x)                     # ***
            x = self.input_drop(x)
        for i, lyer in enumerate(self.convs):
            if self.norm:
                x_res = self.norms[i](x)
                x_res = lyer(x_res, adj)
                x = x + x_res
            else:
                x = lyer(x, adj)
            if i != self.n_layers - 1:
                mid = x
        if self.output_layer:
            x = self.output_normalization(x)
            x = self.output_linear(x).squeeze(1)
        if return_mid:
            return mid, x.squeeze(1)
        else:
            return x.squeeze(1)


class GCN(GCNEncoder):
    def __init__(self, nfeat, nhid, nclass, n_layers=2, dropout=0.5, input_dropout=0.0, norm=None, 
                 n_linear=1, act='F.relu', input_layer=False, output_layer=False, 
                 weight_initializer=None, bias_initializer=None, bias=True):

        super().__init__(nfeat, nhid, nclass, n_layers, dropout, input_dropout, 
                         norm, n_linear, act, input_layer, output_layer, 
                         weight_initializer, bias_initializer, bias)

    def forward(self, x, adj, return_final=False, return_mid=False):
        """
        Add an log_softmax layer after the output layer.
        """

        mid, x = super().forward(x, adj, return_mid=True)

        if return_final:            # for ht loss
            return x
        else:                       # for node classification
            if return_mid:          # for node similarity calc. (in `graph_learner_forward`)
                return mid, F.log_softmax(x, dim=-1)
            else:
                return F.log_softmax(x, dim=-1)


class GraphConvolutionLayer_Anchor(nn.Module):

    def __init__(self, in_features, out_features, dropout=0.5, n_linear=1, bias=True, act='F.relu',
                 last_layer=False, weight_initializer=None, bias_initializer=None):
        """
        """

        super(GraphConvolutionLayer_Anchor, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.mlp = nn.ModuleList()
        self.mlp.append(Linear(in_features, out_features, bias=bias, weight_initializer=weight_initializer, bias_initializer=bias_initializer))
        for i in range(n_linear-1):
            self.mlp.append(Linear(out_features, out_features, bias=bias, weight_initializer=weight_initializer, bias_initializer=bias_initializer))
        self.dropout = dropout
        self.act = eval(act)
        self.last_layer = last_layer

    def forward(self, x, adj, R, miu=0.8, use_anchor=True, use_balance=True):
        """ 
        Graph Convolutional Layer forward function.add()

        `adj`: the original adjacency (a sparse/dense mx, does NOT require gradients)

        `R`: the anchor adjacency (a dense matrix, requires gradients)

        FIX: correct the message passing approach in OpenGSL library to speed up the training process.
        """

        x = self.mlp[0](x)                  # FIX：create the message first, then pass the message
        for i in range(1, len(self.mlp)):
            x = self.mlp[i](x)
            x = self.act(x)
            x = F.dropout(x, p=self.dropout, training=self.training)

        # the normal message passing (dense/sparse)
        if use_balance:
            if adj.is_sparse:
                mp_normal = matmul(SparseTensor.from_torch_sparse_coo_tensor(adj), x)
            else:
                mp_normal = torch.mm(adj, x)

        if use_anchor:
            # the anchor message passing (dense, copied from OpenGSL/IDGL)
            node_norm = R / torch.clamp(torch.sum(R, dim=-2, keepdim=True), min=1e-12)
            anchor_norm = R / torch.clamp(torch.sum(R, dim=-1, keepdim=True), min=1e-12)
            mp_anchor = torch.matmul(anchor_norm, torch.matmul(node_norm.transpose(-1, -2), x))

            # balance the two messages
            if use_balance:
                output = miu * mp_normal + (1 - miu) * mp_anchor
            else:
                output = mp_anchor          # for ht contrastive learning
        else:
            output = mp_normal

        if not self.last_layer:
            output = self.act(output)
            output = F.dropout(output, p=self.dropout, training=self.training)
        return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


class GCNEncoder_Anchor(nn.Module):
    """
    """

    def __init__(self, nfeat, nhid, nclass, n_layers=2, dropout=0.5, input_dropout=0.0, norm=None, n_linear=1,
                 act='F.relu', input_layer=False, output_layer=False, weight_initializer=None,
                 bias_initializer=None, bias=True):
        """
        Overwrite the `__init__` function of `GraphConvolutionLayer`.
        """

        super(GCNEncoder_Anchor, self).__init__()

        self.nfeat = nfeat
        self.nclass = nclass
        self.n_layers = n_layers
        self.input_layer = input_layer
        self.output_layer = output_layer
        self.n_linear = n_linear
        self.norm = norm
        if norm:
            self.norm_type = eval('nn.'+norm['norm_type'])
        self.act = eval(act)
        if input_layer:
            self.input_linear = nn.Linear(in_features=nfeat, out_features=nhid)
            self.input_drop = nn.Dropout(input_dropout)
        if output_layer:
            self.output_linear = nn.Linear(in_features=nhid, out_features=nclass)
            self.output_normalization = self.norm_type(nhid)
        self.convs = nn.ModuleList()
        if self.norm:
            self.norms = nn.ModuleList()
        else:
            self.norms = None

        for i in range(n_layers):
            if i == 0 and not self.input_layer:
                in_hidden = nfeat
            else:
                in_hidden = nhid
            if i == n_layers - 1 and not self.output_layer:
                out_hidden = nclass
            else:
                out_hidden = nhid

            self.convs.append(GraphConvolutionLayer_Anchor(in_hidden, out_hidden, dropout, n_linear, act=act,
                                                    weight_initializer=weight_initializer, bias_initializer=bias_initializer,
                                                    bias=bias))
            if self.norm:
                self.norms.append(self.norm_type(in_hidden))
        self.convs[-1].last_layer = True

    def forward(self, x, adj, R, miu=0.8, return_mid=False, use_anchor=True, use_balance=True):
        """
        Overwrite the `forward` function to fit the new `GraphConvolutionLayer_Anchor`.
        """

        if self.input_layer:
            x = self.input_linear(x)
            x = self.act(x)                     # ***
            x = self.input_drop(x)

        for i, lyer in enumerate(self.convs):
            if self.norm:
                x_res = self.norms[i](x)
                x_res = lyer(x_res, adj, R, miu, use_anchor=use_anchor, use_balance=use_balance)
                x = x + x_res
            else:
                x = lyer(x, adj, R, miu, use_anchor=use_anchor, use_balance=use_balance)
            if i != self.n_layers - 1:
                mid = x
        if self.output_layer:
            x = self.output_normalization(x)
            x = self.output_linear(x).squeeze(1)
        if return_mid:
            return mid, x.squeeze(1)
        else:
            return x.squeeze(1)


class GCN_Anchor(GCNEncoder_Anchor):
    def __init__(self, nfeat, nhid, nclass, n_layers=2, dropout=0.5, input_dropout=0, norm=None, 
                 n_linear=1, act='F.relu', input_layer=False, output_layer=False, 
                 weight_initializer=None, bias_initializer=None, bias=True):

        super().__init__(nfeat, nhid, nclass, n_layers, dropout, input_dropout, 
                         norm, n_linear, act, input_layer, output_layer, 
                         weight_initializer, bias_initializer, bias)

    def forward(self, x, adj, R, miu=0.8, return_final=False, use_anchor=True, use_balance=True, return_mid=False):
        """
        Add an log_softmax layer after the output layer.
        """

        mid, x = super().forward(x, adj, R, miu, use_anchor=use_anchor, use_balance=use_balance, return_mid=True)

        if return_final:            # for ht loss
            return x
        else:                       # for node classification
            if return_mid:          # for node similarity calc. (in `graph_learner_forward`)
                return mid, F.log_softmax(x, dim=-1)
            else:
                return F.log_softmax(x, dim=-1)


class UniGCNIIConv_csr(MessagePassing):
    """
    A reproducible version of UniGNN.

    Paper "UniGNN: a Unified Framework for Graph and Hypergraph Neural Networks".
    """

    def __init__(self, in_features, out_features, **kwargs):
        super().__init__()
        kwargs.setdefault('aggr', 'add')
        kwargs.setdefault('flow', 'source_to_target')
        self.W = nn.Linear(in_features, out_features, bias=False)

        self.reset_parameters()

    def forward(self, X, hyperedge_index, alpha, beta, X0, degV, degE, num_all_he_dhg) :
        """
        """

        N = X.shape[0]

        # sort the hyperedge_index by the second row (E)
        sorted_indices = torch.argsort(hyperedge_index[1], dim=0, descending=False, stable=True)
        hyperedge_index = hyperedge_index[:, sorted_indices]
        Xve = X[hyperedge_index[0]]
        indptr = torch._convert_indices_from_coo_to_csr(hyperedge_index[1], num_all_he_dhg, out_int32=False)
        Xe = segment_csr(src=Xve, indptr=indptr, reduce='mean')

        Xe = Xe * degE

        # sort the hyperedge_index by the first row (V)
        sorted_indices = torch.argsort(hyperedge_index[0], dim=0, descending=False, stable=True)
        hyperedge_index = hyperedge_index[:, sorted_indices]
        Xev = Xe[hyperedge_index[1]]
        indptr = torch._convert_indices_from_coo_to_csr(hyperedge_index[0], N, out_int32=False)
        Xv = segment_csr(src=Xev, indptr=indptr, reduce='sum')

        Xv = Xv * degV

        X = Xv

        Xi = (1-alpha) * X + alpha * X0
        X = (1-beta) * Xi + beta * self.W(Xi)

        return X

    def reset_parameters(self):
        # kaiming
        nn.init.kaiming_uniform_(self.W.weight, mode='fan_in', nonlinearity='relu')


class HyperEncoder_csr(nn.Module):

    def __init__(self, in_dim, edge_dim, drop_p = 0.5, num_layers=2, cached = False):
        super(HyperEncoder_csr, self).__init__()
        self.in_dim = in_dim
        self.edge_dim = edge_dim
        self.num_layers = num_layers
        self.drop_p = drop_p
        self.convs = nn.ModuleList()

        self.lamda, self.alpha = 0.5, 0.1
        self.convs.append(torch.nn.Linear(self.in_dim, self.edge_dim))
        for _ in range(self.num_layers) : 
            self.convs.append(UniGCNIIConv_csr(self.edge_dim, self.edge_dim))

        self.reset_parameters()

    def reset_parameters(self):
        for conv in self.convs:
            if isinstance(conv, torch.nn.Linear):
                # kaiming
                nn.init.kaiming_uniform_(conv.weight, mode='fan_in', nonlinearity='relu')
                if conv.bias is not None:
                    conv.bias.data.fill_(0.01)
                print("HyperEncoder: Linear initialized.")
            else:
                conv.reset_parameters()                 # UniGCNIIConv
                print("HyperEncoder: UniGCNIIConv initialized.")

    def get_degree_of_hypergraph(self, hyperedge_index, num_all_e_dhg, num_all_he_dhg, device) : ## For UNIGCNII
        """
        """

        ones = torch.ones(hyperedge_index[0].shape[0], 
                          dtype=torch.int64).to(device)

        sorted_indices = torch.argsort(hyperedge_index[0], dim=0, descending=False, stable=True)
        hyperedge_index = hyperedge_index[:, sorted_indices]
        indptr = torch._convert_indices_from_coo_to_csr(hyperedge_index[0], num_all_e_dhg, out_int32=False)
        dV = segment_csr(src=ones, indptr=indptr, reduce='mean')

        del ones

        sorted_indices = torch.argsort(hyperedge_index[1], dim=0, descending=False, stable=True)
        hyperedge_index = hyperedge_index[:, sorted_indices]
        indptr = torch._convert_indices_from_coo_to_csr(hyperedge_index[1], num_all_he_dhg, out_int32=False)
        dE = segment_csr(src=dV[hyperedge_index[0]], indptr=indptr, reduce='mean')

        dV = dV.pow(-0.5)
        dE = dE.pow(-0.5)
        dV[dV.isinf()] = 1
        dE[dE.isinf()] = 1

        return dV.reshape(-1, 1), dE.reshape(-1, 1)

    def forward(self, x: torch.Tensor, hyperedge_index: torch.Tensor, num_all_he_dhg: int):

        num_all_e_dhg = x.shape[0]

        degV, degE = self.get_degree_of_hypergraph(hyperedge_index, num_all_e_dhg, 
                                              num_all_he_dhg, hyperedge_index.device) # Getting degree
        degV = degV.reshape(-1, 1)
        degE = degE.reshape(-1, 1)

        x = torch.relu(self.convs[0](x))
        x = F.dropout(x, p=self.drop_p, training=self.training)                # *** fix: input dropout
        x0 = x

        # UniGCNIIConv layers
        for i, conv in enumerate(self.convs[1:]) : 
            # x = F.dropout(x, p=self.drop_p, training=self.training)
            beta = math.log(self.lamda/(i+1)+1)
            if i == len(self.convs[1:]) - 1 : 
                x = conv(x, hyperedge_index, self.alpha, beta, x0, degV, degE, num_all_he_dhg)
            else :
                x = conv(x, hyperedge_index, self.alpha, beta, x0, degV, degE, num_all_he_dhg)
                x = torch.relu(x)
                x = F.dropout(x, p=self.drop_p, training=self.training)        # *** fix: input dropout

        return x # Only Returns Node Embeddings


class MLP(nn.Module):
    """

    adapted from https://github.com/CUAI/CorrectAndSmooth/blob/master/gen_models.py 

    (Edited)
    """

    def __init__(self, in_channels, hidden_channels, out_channels, num_layers,
                 dropout=.5, Normalization='bn', InputNorm=False, gn_num_groups=3):
        super(MLP, self).__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels

        self.lins = nn.ModuleList()
        self.normalizations = nn.ModuleList()
        self.InputNorm = InputNorm

        assert Normalization in ['bn', 'ln', 'gn', 'None']
        if Normalization == 'bn':
            if num_layers == 1:
                # just linear layer i.e. logistic regression
                if InputNorm:
                    self.normalizations.append(nn.BatchNorm1d(in_channels))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(nn.Linear(in_channels, out_channels))
            else:
                if InputNorm:
                    self.normalizations.append(nn.BatchNorm1d(in_channels))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(nn.Linear(in_channels, hidden_channels))
                self.normalizations.append(nn.BatchNorm1d(hidden_channels))
                for _ in range(num_layers - 2):
                    self.lins.append(
                        nn.Linear(hidden_channels, hidden_channels))
                    self.normalizations.append(nn.BatchNorm1d(hidden_channels))
                self.lins.append(nn.Linear(hidden_channels, out_channels))
        elif Normalization == 'ln':
            if num_layers == 1:
                # just linear layer i.e. logistic regression
                if InputNorm:
                    self.normalizations.append(nn.LayerNorm(in_channels))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(nn.Linear(in_channels, out_channels))
            else:
                if InputNorm:
                    self.normalizations.append(nn.LayerNorm(in_channels))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(nn.Linear(in_channels, hidden_channels))
                self.normalizations.append(nn.LayerNorm(hidden_channels))
                for _ in range(num_layers - 2):
                    self.lins.append(
                        nn.Linear(hidden_channels, hidden_channels))
                    self.normalizations.append(nn.LayerNorm(hidden_channels))
                self.lins.append(nn.Linear(hidden_channels, out_channels))
        elif Normalization == 'gn':
            if num_layers == 1:
                # just linear layer i.e. logistic regression
                if InputNorm:
                    self.normalizations.append(nn.GroupNorm(gn_num_groups, in_channels))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(nn.Linear(in_channels, out_channels))
            else:
                if InputNorm:
                    self.normalizations.append(nn.GroupNorm(gn_num_groups, in_channels))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(nn.Linear(in_channels, hidden_channels))
                self.normalizations.append(nn.GroupNorm(gn_num_groups, hidden_channels))
                for _ in range(num_layers - 2):
                    self.lins.append(
                        nn.Linear(hidden_channels, hidden_channels))
                    self.normalizations.append(nn.GroupNorm(gn_num_groups, hidden_channels))
                self.lins.append(nn.Linear(hidden_channels, out_channels))
        else:
            if num_layers == 1:
                # just linear layer i.e. logistic regression
                self.normalizations.append(nn.Identity())
                self.lins.append(nn.Linear(in_channels, out_channels))
            else:
                self.normalizations.append(nn.Identity())
                self.lins.append(nn.Linear(in_channels, hidden_channels))
                self.normalizations.append(nn.Identity())
                for _ in range(num_layers - 2):
                    self.lins.append(
                        nn.Linear(hidden_channels, hidden_channels))
                    self.normalizations.append(nn.Identity())
                self.lins.append(nn.Linear(hidden_channels, out_channels))

        self.dropout = dropout

    def reset_parameters(self, mode='relu'):
        if mode == 'sigmoid':
            for i, lin in enumerate(self.lins):
                if i + 1 >= len(self.lins) and isinstance(lin, nn.Linear):
                    # the last layer (sigmoid): xavier + small positive bias
                    torch.nn.init.xavier_uniform_(lin.weight, gain=1.0)
                    lin.bias.data.fill_(0.01)
                elif isinstance(lin, nn.Linear):
                    # kaiming for relu
                    torch.nn.init.kaiming_uniform_(lin.weight, nonlinearity='relu', mode='fan_in')
                    lin.bias.data.fill_(0.01)
        elif mode == 'relu':
            for i, lin in enumerate(self.lins):
                if isinstance(lin, nn.Linear):
                    # kaiming
                    torch.nn.init.kaiming_uniform_(lin.weight, nonlinearity='relu', mode='fan_in')
                    lin.bias.data.fill_(0.01)
        elif mode == 'tanh':
            for i, lin in enumerate(self.lins):
                if i + 1 >= len(self.lins) and isinstance(lin, nn.Linear):
                    # the last layer (tanh): xavier + small positive bias
                    torch.nn.init.xavier_uniform_(lin.weight, gain=5/3)
                    lin.bias.data.fill_(0.01)
                elif isinstance(lin, nn.Linear):
                    # kaiming for relu
                    torch.nn.init.kaiming_uniform_(lin.weight, nonlinearity='relu', mode='fan_in')
                    lin.bias.data.fill_(0.01)
        else:       # *** eye (for input feature transformation)
            # https://pytorch.org/docs/stable/nn.init.html#torch.nn.init.eye_
            for lin in self.lins:
                torch.nn.init.eye_(lin.weight)
                if lin.bias is not None:
                    # torch.nn.init.zeros_(lin.bias)
                    lin.bias.data.fill_(0.01)
        for normalization in self.normalizations:
            if not (normalization.__class__.__name__ == 'Identity'):
                normalization.reset_parameters()

    def forward(self, x):
        """
        https://github.com/ducha-aiki/caffenet-benchmark/blob/master/batchnorm.md
        """
        x = self.normalizations[0](x)
        for i, lin in enumerate(self.lins[:-1]):
            x = lin(x)
            x = F.relu(x, inplace=True)
            x = self.normalizations[i+1](x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.lins[-1](x)
        return x

    def flops(self, x):
        num_samples = np.prod(x.shape[:-1])
        flops = num_samples * self.in_channels # first normalization
        flops += num_samples * self.in_channels * self.hidden_channels # first linear layer
        flops += num_samples * self.hidden_channels # first relu layer

        # flops for each layer
        per_layer = num_samples * self.hidden_channels * self.hidden_channels
        per_layer += num_samples * self.hidden_channels # relu + normalization
        flops += per_layer * (len(self.lins) - 2)

        flops += num_samples * self.out_channels * self.hidden_channels # last linear layer

        return flops


class Diag(nn.Module):
    """
    Borrowed from SLAPS (edited).

    https://github.com/BorealisAI/SLAPS-GNN
    """

    def __init__(self, input_size):
        super(Diag, self).__init__()

        self.input_size = input_size

        self.weights = nn.Parameter(torch.Tensor(1, self.input_size))

    def forward(self, input):
        res = torch.einsum('ij,...j->ij', input, self.weights)
        return res

    def reset_parameters(self, mode='relu'):
        if mode == 'sigmoid':
            torch.nn.init.xavier_uniform_(self.weights)
        elif mode == 'relu':
            torch.nn.init.kaiming_uniform_(self.weights, nonlinearity='relu', mode='fan_in')
        elif mode == 'ones':       # *** ones (for input feature transformation)
            torch.nn.init.ones_(self.weights)
        elif mode == 'tanh':
            torch.nn.init.xavier_uniform_(self.weights, gain=5/3)
        else:
            raise Exception('`Diag`: Invalid mode!')


class MLP_Diag(nn.Module):
    """
    Borrowed from SLAPS (edited).

    https://github.com/BorealisAI/SLAPS-GNN
    """

    def __init__(self, num_layers, input_size, mlp_act='F.relu', dropout=0.5, 
                    Normalization='bn', InputNorm=False, gn_num_groups=3):
        super(MLP_Diag, self).__init__()

        self.num_layers = num_layers
        self.input_size = input_size
        self.lins = nn.ModuleList()
        self.normalizations = nn.ModuleList()
        self.InputNorm = InputNorm

        assert Normalization in ['bn', 'ln', 'gn', 'None']
        if Normalization == 'bn':
            if num_layers == 1:
                # just linear layer i.e. logistic regression
                if InputNorm:
                    self.normalizations.append(nn.BatchNorm1d(input_size))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(Diag(input_size))
            else:
                if InputNorm:
                    self.normalizations.append(nn.BatchNorm1d(input_size))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(Diag(input_size))
                self.normalizations.append(nn.BatchNorm1d(input_size))
                for _ in range(num_layers - 2):
                    self.lins.append(
                        Diag(input_size))
                    self.normalizations.append(nn.BatchNorm1d(input_size))
                self.lins.append(Diag(input_size))
        elif Normalization == 'ln':
            if num_layers == 1:
                # just linear layer i.e. logistic regression
                if InputNorm:
                    self.normalizations.append(nn.LayerNorm(input_size))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(Diag(input_size))
            else:
                if InputNorm:
                    self.normalizations.append(nn.LayerNorm(input_size))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(Diag(input_size))
                self.normalizations.append(Diag(input_size))
                for _ in range(num_layers - 2):
                    self.lins.append(
                        Diag(input_size))
                    self.normalizations.append(nn.LayerNorm(input_size))
                self.lins.append(Diag(input_size))
        elif Normalization == 'gn':
            if num_layers == 1:
                # just linear layer i.e. logistic regression
                if InputNorm:
                    self.normalizations.append(nn.GroupNorm(gn_num_groups, input_size))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(Diag(input_size))
            else:
                if InputNorm:
                    self.normalizations.append(nn.GroupNorm(gn_num_groups, input_size))
                else:
                    self.normalizations.append(nn.Identity())
                self.lins.append(Diag(input_size))
                self.normalizations.append(nn.GroupNorm(gn_num_groups, input_size))
                for _ in range(num_layers - 2):
                    self.lins.append(
                        Diag(input_size))
                    self.normalizations.append(nn.GroupNorm(gn_num_groups, input_size))
                self.lins.append(Diag(input_size))
        else:
            if num_layers == 1:
                # just linear layer i.e. logistic regression
                self.normalizations.append(nn.Identity())
                self.lins.append(Diag(input_size))
            else:
                self.normalizations.append(nn.Identity())
                self.lins.append(Diag(input_size))
                self.normalizations.append(nn.Identity())
                for _ in range(num_layers - 2):
                    self.lins.append(
                        Diag(input_size))
                    self.normalizations.append(nn.Identity())
                self.lins.append(Diag(input_size))

        self.mlp_act = eval(mlp_act)
        self.dropout = dropout
    
    def reset_parameters(self, mode='relu'):
        if mode == 'sigmoid':
            for i, lin in enumerate(self.lins):
                if i + 1 >= len(self.lins) and isinstance(lin, Diag):
                    # the last layer (sigmoid): xavier + small positive bias
                    lin.reset_parameters('sigmoid')
                elif isinstance(lin, Diag):
                    # kaiming for relu
                    lin.reset_parameters('relu')
        elif mode == 'relu':
            for i, lin in enumerate(self.lins):
                if isinstance(lin, Diag):
                    # kaiming
                    lin.reset_parameters('relu')
        elif mode == 'tanh':
            for i, lin in enumerate(self.lins):
                if isinstance(lin, Diag):
                    # xavier
                    lin.reset_parameters('tanh')
        else:       # *** eye (for input feature transformation)
            # https://pytorch.org/docs/stable/nn.init.html#torch.nn.init.eye_
            for lin in self.lins:
                lin.reset_parameters('ones')
        for normalization in self.normalizations:
            if not (normalization.__class__.__name__ == 'Identity'):
                normalization.reset_parameters()

    def forward(self, x):    
        x = self.normalizations[0](x)
        for i, lin in enumerate(self.lins[:-1]):
            x = lin(x)
            x = self.mlp_act(x)
            x = self.normalizations[i+1](x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.lins[-1](x)
        return x


import random
from multiset import Multiset
from math import ceil, floor, comb
from itertools import combinations
from typing import Optional, Callable, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch import linalg as LA

from torch_scatter import segment_csr

from utils.logger import MyLogger
from utils.procs import split_batch

from model.gnns import MLP, GCN_Anchor, GCN




def compute_pn_similarity(aggQuery: Tensor, aggKey: Tensor) -> Tuple[Tensor, Tensor]:
    """
    """

    similarity_matrix = torch.einsum('ik,jk->ij', aggQuery, aggKey)

    negative_matrix = torch.ones(similarity_matrix.shape, dtype=torch.bool, 
                                 device=similarity_matrix.device).fill_diagonal_(False)

    return similarity_matrix.diag(0), similarity_matrix.view(-1)[negative_matrix.view(-1)]


class CircleLoss(nn.Module):
    def __init__(self, m: float, gamma: float, temp: float) -> None:

        super(CircleLoss, self).__init__()

        # circle loss parameters
        self.m = m
        self.gamma = gamma
        self.delta_p = 1 - self.m
        self.delta_n = self.m
        self.op = 1 + self.m
        self.on = - self.m
        self.temp = temp

        self.soft_plus = nn.Softplus()

    def forward(self, aggQuery: Tensor, aggKey: Tensor):
        """
        """

        sp, sn = compute_pn_similarity(aggQuery, aggKey)

        ap = torch.clamp_min(self.op - sp.detach(), min=0.)
        an = torch.clamp_min(sn.detach() - self.on, min=0.)

        ap = torch.pow(ap, self.temp)
        an = torch.pow(an, self.temp)

        logit_p = - self.gamma * ap * (sp - self.delta_p)
        logit_n =   self.gamma * an * (sn - self.delta_n)

        loss = self.soft_plus(torch.logsumexp(logit_n, dim=0) + torch.logsumexp(logit_p, dim=0))

        return loss


class Head_Tail_Anc_GNN(nn.Module):
    """
    Credits: SUBLIME & PROSE.
    """

    def __init__(self, 
                 gnn_in_channels: int, 
                 gnn_hidden_channels: int, 
                 gnn_out_channels: int, 
                 gnn_num_layers: int, 
                 gnn_dropout: float, 
                 proj_hidden_channels: int, 
                 proj_out_channels: int, 
                 proj_num_layers: int, 
                 proj_Normalization: str):
        super(Head_Tail_Anc_GNN, self).__init__()

        self.gnn_model = GCN_Anchor(gnn_in_channels, gnn_hidden_channels, 
                                    gnn_out_channels, gnn_num_layers, gnn_dropout)

        self.ht_proj_head = MLP(gnn_out_channels, proj_hidden_channels, 
                                proj_out_channels, proj_num_layers, 0.0, proj_Normalization)

        self.ht_proj_head.reset_parameters('relu')

    def proj_feats(self, feats: Tensor):
        return self.ht_proj_head(feats)

    def __loss(self, z1: Tensor, z2: Tensor, temperature=0.2, sym=True):

        batch_size, _ = z1.size()

        z1_abs = LA.norm(z1, ord=2, dim=1)
        z2_abs = LA.norm(z2, ord=2, dim=1)

        sim_matrix = torch.einsum('ik,jk->ij', z1, z2) \
                   / (torch.einsum('i,j->ij', z1_abs, z2_abs) + 1e-12)
        sim_matrix = torch.exp(sim_matrix / temperature)
        pos_sim = sim_matrix[range(batch_size), range(batch_size)]

        if sym:

            loss_0 = pos_sim / sim_matrix.sum(dim=0)
            loss_1 = pos_sim / sim_matrix.sum(dim=1)

            loss_0 = - torch.log(loss_0).mean()
            loss_1 = - torch.log(loss_1).mean()
            loss = (loss_0 + loss_1) / 2.0
            return loss
        else:
            loss_1 = pos_sim / sim_matrix.sum(dim=1)
            loss_1 = - torch.log(loss_1).mean()
            return loss_1

    def loss(self, features_v1, features_v2, params):

        num_nodes_all = features_v1.shape[0]

        # compute loss
        if params['gl_ht_batch_size']:
            node_idxs = list(range(num_nodes_all))
            random.shuffle(node_idxs)           # ***
            batches = split_batch(node_idxs, params['gl_ht_batch_size'])
            loss = 0
            for batch in batches:
                weight = len(batch) / num_nodes_all
                loss += weight * self.__loss(features_v1[batch], features_v2[batch])
        else:
            loss = self.__loss(features_v1, features_v2)
        
        return loss


class Head_Tail_Ori_GNN(nn.Module):
    """
    Credits: SUBLIME & PROSE.
    """

    def __init__(self, 
                 gnn_in_channels: int, 
                 gnn_hidden_channels: int, 
                 gnn_out_channels: int, 
                 gnn_num_layers: int, 
                 gnn_dropout: float, 
                 proj_hidden_channels: int, 
                 proj_out_channels: int, 
                 proj_num_layers: int, 
                 proj_Normalization: str):
        super(Head_Tail_Ori_GNN, self).__init__()

        self.gnn_model = GCN(gnn_in_channels, gnn_hidden_channels, 
                             gnn_out_channels, gnn_num_layers, gnn_dropout)

        self.ht_proj_head = MLP(gnn_out_channels, proj_hidden_channels, 
                                proj_out_channels, proj_num_layers, 0.0, proj_Normalization)

        self.ht_proj_head.reset_parameters('relu')

    def proj_feats(self, feats: Tensor):
        return self.ht_proj_head(feats)

    def __loss(self, z1: Tensor, z2: Tensor, temperature=0.2, sym=True):

        batch_size, _ = z1.size()

        z1_abs = LA.norm(z1, ord=2, dim=1)
        z2_abs = LA.norm(z2, ord=2, dim=1)

        sim_matrix = torch.einsum('ik,jk->ij', z1, z2) \
                   / (torch.einsum('i,j->ij', z1_abs, z2_abs) + 1e-12)
        sim_matrix = torch.exp(sim_matrix / temperature)
        pos_sim = sim_matrix[range(batch_size), range(batch_size)]

        if sym:

            loss_0 = pos_sim / sim_matrix.sum(dim=0)
            loss_1 = pos_sim / sim_matrix.sum(dim=1)

            loss_0 = - torch.log(loss_0).mean()
            loss_1 = - torch.log(loss_1).mean()
            loss = (loss_0 + loss_1) / 2.0
            return loss
        else:
            loss_1 = pos_sim / sim_matrix.sum(dim=1)
            loss_1 = - torch.log(loss_1).mean()
            return loss_1

    def loss(self, features_v1, features_v2, params):

        num_nodes_all = features_v1.shape[0]

        # compute loss
        if params['gl_ht_batch_size']:
            node_idxs = list(range(num_nodes_all))
            random.shuffle(node_idxs)           # ***
            batches = split_batch(node_idxs, params['gl_ht_batch_size'])
            loss = 0
            for batch in batches:
                weight = len(batch) / num_nodes_all
                loss += weight * self.__loss(features_v1[batch], features_v2[batch])
        else:
            loss = self.__loss(features_v1, features_v2)
        
        return loss


class DHG_ECL(nn.Module):
    """
    Borrowed from Tri-CL (AAAI 2023): \
        "I'm Me, We're Us, and I'm Us: Tri-directional Contrastive Learning on Hypergraphs".
    Link: https://github.com/wooner49/TriCL

    """
    def __init__(self, edge_dim: int, proj_dim: int):
        super(DHG_ECL, self).__init__()

        self.edge_dim = edge_dim
        self.proj_dim = proj_dim

        # projection layers for edge features
        self.fc1_e = nn.Linear(self.edge_dim, self.proj_dim)
        self.fc2_e = nn.Linear(self.proj_dim, self.edge_dim)

        self.reset_parameters()

    def reset_parameters(self):
        # kaiming
        nn.init.kaiming_uniform_(self.fc1_e.weight, mode='fan_in', nonlinearity='relu')
        nn.init.kaiming_uniform_(self.fc2_e.weight, mode='fan_in', nonlinearity='relu')
        self.fc1_e.bias.data.fill_(0.01)
        self.fc2_e.bias.data.fill_(0.01)

    def f(self, x, tau):
        return torch.exp(x / tau)

    def edge_projection(self, z: Tensor):
        return self.fc2_e(F.elu(self.fc1_e(z)))

    def cosine_similarity(self, z1: Tensor, z2: Tensor):
        z1 = F.normalize(z1)
        z2 = F.normalize(z2)
        return torch.einsum('ik,jk->ij', z1, z2)

    def __semi_loss(self, h1: Tensor, h2: Tensor, tau: float, num_negs: Optional[int]):
        """
        Full-batch version of the edge contrastive loss.

        `num_negs` is used to get more negative samples.
        """

        if num_negs is None:
            between_sim = self.f(self.cosine_similarity(h1, h2), tau)
            return -torch.log(between_sim.diag() / between_sim.sum(1))
        else:
            pos_sim = self.f(F.cosine_similarity(h1, h2), tau)
            negs = []
            for _ in range(num_negs):
                negs.append(h2[torch.randperm(h2.size(0))])
            negs = torch.stack(negs, dim=-1)
            neg_sim = self.f(F.cosine_similarity(h1.unsqueeze(-1).tile(num_negs), negs), tau)
            return -torch.log(pos_sim / (pos_sim + neg_sim.sum(1)))

    def __semi_loss_batch(self, h1: Tensor, h2: Tensor, tau: float):
        """
        """

        batch_size, _ = h1.size()

        h1_abs = LA.norm(h1, ord=2, dim=1)
        h2_abs = LA.norm(h2, ord=2, dim=1)

        sim_matrix = torch.einsum('ik,jk->ij', h1, h2) \
                   / (torch.einsum('i,j->ij', h1_abs, h2_abs) + 1e-12)
        sim_matrix = torch.exp(sim_matrix / tau)
        pos_sim = sim_matrix[range(batch_size), range(batch_size)]

        loss = pos_sim / sim_matrix.sum(dim=1)
        loss = - torch.log(loss).mean()

        return loss

    def __loss(self, z1: Tensor, z2: Tensor, tau: float, batch_size: Optional[int], 
               num_negs: Optional[int], mean: bool):

        if batch_size is None:
            l1 = self.__semi_loss(z1, z2, tau, num_negs)
            l2 = self.__semi_loss(z2, z1, tau, num_negs)
            loss = (l1 + l2) * 0.5
            loss = loss.mean() if mean else loss.sum()
            return loss

        else:               # *** fix
            num_ent_all = z1.shape[0]
            ent_idxs = list(range(num_ent_all))
            random.shuffle(ent_idxs)
            batches = split_batch(ent_idxs, batch_size)
            loss1 = 0
            loss2 = 0
            for batch in batches:
                weight = len(batch) / num_ent_all
                loss1 += weight * self.__semi_loss_batch(z1[batch], z2[batch], tau)
                loss2 += weight * self.__semi_loss_batch(z2[batch], z1[batch], tau)
            return (loss1 + loss2) * 0.5

    def edge_level_loss(self, n1: Tensor, n2: Tensor, node_tau: float, 
                       batch_size: Optional[int] = None, num_negs: Optional[int] = None, 
                       mean: bool = True):
        loss = self.__loss(n1, n2, node_tau, batch_size, num_negs, mean)
        return loss


class key_query_mapper(nn.Module) : 
    """
    Borrowed from HYPEBOY (ICLR 2024): \
        "HypeBoy: Generative Self-Supervised Representation Learning on Hypergraphs".
    Link: https://github.com/kswoo97/hypeboy
    """

    def __init__(self, hidden_dim):
        super(key_query_mapper, self).__init__()

        self.W1 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.W2 = torch.nn.Linear(hidden_dim, hidden_dim)

    def reset_parameters(self):
        # kaiming
        nn.init.kaiming_uniform_(self.W1.weight, mode='fan_in', nonlinearity='relu')
        nn.init.kaiming_uniform_(self.W2.weight, mode='fan_in', nonlinearity='relu')
        self.W1.bias.data.fill_(0.01)
        self.W2.bias.data.fill_(0.01)

    def forward(self, Z):
        return self.W2(torch.relu(self.W1(Z)))          # Encode given embedding


class HEBF_csr(nn.Module):
    """
    Credit: 
    
        HYPEBOY (ICLR 2024): \
            "HypeBoy: Generative Self-Supervised Representation Learning on Hypergraphs".
        Link: https://github.com/kswoo97/hypeboy
    """

    def __init__(self, edge_dim, m, gamma, temp):

        super(HEBF_csr, self).__init__()

        self.edge_dim = edge_dim

        # projection layers for HEBF
        self.key_mapper = key_query_mapper(self.edge_dim)
        self.query_mapper = key_query_mapper(self.edge_dim)

        # circle loss for similarity learning
        self.loss_func = CircleLoss(m, gamma, temp)

        self.reset_parameters()

    def reset_parameters(self):
        # kaiming
        self.key_mapper.reset_parameters()
        self.query_mapper.reset_parameters()

    def f(self, x, tau):
        return torch.exp(x / tau)

    def he_projection(self, z: Tensor):
        return self.fc2_he(F.elu(self.fc1_he(z)))

    def cosine_similarity(self, z1: Tensor, z2: Tensor):
        z1 = F.normalize(z1)
        z2 = F.normalize(z2)
        return torch.einsum('ik,jk->ij', z1, z2)

    @staticmethod
    def max_min_he_feat_layer(edge_feat: Tensor, dhg_index: Tensor, is_sorted: bool=False):
        """
        Re-implementation of the hyperedge feature generation scheme in the following paper:
        NHP (CIKM 2020): \
            "NHP: Neural Hypergraph Link Prediction".
        Link: https://drive.google.com/file/d/1pgSPvv6Y23X5cPiShCpF4bU8eqz_34YE/view?usp=sharing
        """

        num_all_he_dhg = dhg_index[1].max().item() + 1

        if not is_sorted:
            sorted_indices = torch.argsort(dhg_index[1], dim=0, descending=False, stable=True)
            dhg_index = dhg_index[:, sorted_indices]

        edge_feat_mp = edge_feat[dhg_index[0, :]]
        indptr = torch._convert_indices_from_coo_to_csr(dhg_index[1], num_all_he_dhg, out_int32=False)

        he_channel_max = segment_csr(edge_feat_mp, indptr, reduce='max')
        he_channel_min = segment_csr(edge_feat_mp, indptr, reduce='min')

        return he_channel_max - he_channel_min

    @staticmethod
    def mean_he_feat_layer(edge_feat: Tensor, dhg_index: Tensor, is_sorted: bool=False):

        num_all_he_dhg = dhg_index[1].max().item() + 1

        if not is_sorted:
            sorted_indices = torch.argsort(dhg_index[1], dim=0, descending=False, stable=True)
            dhg_index = dhg_index[:, sorted_indices]

        edge_feat_mp = edge_feat[dhg_index[0, :]]
        indptr = torch._convert_indices_from_coo_to_csr(dhg_index[1], num_all_he_dhg, out_int32=False)

        he_channel_mean = segment_csr(edge_feat_mp, indptr, reduce='mean')

        return he_channel_mean

    def __semi_loss(self, h1: Tensor, h2: Tensor, tau: float, num_negs: Optional[int]):
        """
        """
        if num_negs is None:
            between_sim = self.f(self.cosine_similarity(h1, h2), tau)
            return -torch.log(between_sim.diag() / between_sim.sum(1))
        else:
            pos_sim = self.f(F.cosine_similarity(h1, h2), tau)
            negs = []
            for _ in range(num_negs):
                negs.append(h2[torch.randperm(h2.size(0))])
            negs = torch.stack(negs, dim=-1)
            neg_sim = self.f(F.cosine_similarity(h1.unsqueeze(-1).tile(num_negs), negs), tau)
            return -torch.log(pos_sim / (pos_sim + neg_sim.sum(1)))

    def __semi_loss_batch(self, h1: Tensor, h2: Tensor, tau: float):
        """
        """

        batch_size, _ = h1.size()

        h1_abs = LA.norm(h1, ord=2, dim=1)
        h2_abs = LA.norm(h2, ord=2, dim=1)

        sim_matrix = torch.einsum('ik,jk->ij', h1, h2) \
                   / (torch.einsum('i,j->ij', h1_abs, h2_abs) + 1e-12)
        sim_matrix = torch.exp(sim_matrix / tau)
        pos_sim = sim_matrix[range(batch_size), range(batch_size)]

        loss = pos_sim / sim_matrix.sum(dim=1)      # robustness
        loss = - torch.log(loss).mean()

        return loss

    def __contrastive_loss(self, z1: Tensor, z2: Tensor, tau: float, batch_size: Optional[int], 
               num_negs: Optional[int], mean: bool):

        if batch_size is None:
            l1 = self.__semi_loss(z1, z2, tau, num_negs)
            l2 = self.__semi_loss(z2, z1, tau, num_negs)
            loss = (l1 + l2) * 0.5
            loss = loss.mean() if mean else loss.sum()
            return loss

        else:               # *** fix
            num_ent_all = z1.shape[0]
            ent_idxs = list(range(num_ent_all))
            random.shuffle(ent_idxs)
            batches = split_batch(ent_idxs, batch_size)
            loss1 = 0
            loss2 = 0
            for batch in batches:
                weight = len(batch) / num_ent_all
                loss1 += weight * self.__semi_loss_batch(z1[batch], z2[batch], tau)
                loss2 += weight * self.__semi_loss_batch(z2[batch], z1[batch], tau)
            return (loss1 + loss2) * 0.5

    def construct_HE_list_wto_loops(self, dhg_index: Tensor):
        """
        """

        he_idx = 0
        prev_indptr = 0

        dhg_index_row = dhg_index[0].tolist()
        dhg_index_col = dhg_index[1].tolist()

        self.totalHE_wto_loops = []
        self.he_size_wto_loops = []
        self.he_idx_list_wto_loops = []

        for i in range(dhg_index.shape[1]) : 
            cur_he_index = dhg_index_col[i]
            if i == 0 :
                he_idx = cur_he_index
            if he_idx != cur_he_index : 
                if i - prev_indptr > 1 : 
                    he = dhg_index_row[prev_indptr : i]
                    random.shuffle(he) 
                    self.totalHE_wto_loops.append(he)
                    self.he_size_wto_loops.append(i - prev_indptr)
                    self.he_idx_list_wto_loops.append(he_idx)
                he_idx = cur_he_index
                prev_indptr = i

        if i - prev_indptr > 1 : 
            he = dhg_index_row[prev_indptr : i + 1]
            random.shuffle(he)       
            self.totalHE_wto_loops.append(he)
            self.he_size_wto_loops.append(i - prev_indptr)
            self.he_idx_list_wto_loops.append(he_idx)

    def generate_key_query_list_train(self, hebf_he_batch_size: int=-1, hebf_key_batch_ratio: float=-1, hebf_pair_num: int=-1, 
                            mylogger: MyLogger=None, device: str='cuda'):
        """
        Prepare the query-key pairs for HEBF loss computation.

        Use `self.totalHE_wto_loops` to avoid the hyperedges that only contain a single edge.

        """

        if hebf_he_batch_size <= 0 :

            self.hebf_use_he_batch = False

            queryEs = []       
            queryIDX = []      
            keyEs = []        
            keyIDX = []        

            pair_idx = 0          

            for i, he in enumerate(self.totalHE_wto_loops) :

                Es = he
                Es_set = Multiset(Es)

                key_batch_size = floor(len(Es) * hebf_key_batch_ratio)
                query_size = len(Es) - key_batch_size
                if key_batch_size < 1:
                    key_batch_size = 1
                    query_size = len(Es) - key_batch_size

                if query_size < 1 :
                    query_size = 1
                    key_batch_size = len(Es) - query_size

                # calculate the exact possible number of pairs
                max_pair_num = comb(len(Es), key_batch_size)

                # generate the key-query pairs
                if hebf_pair_num > max_pair_num :   
                    for key in combinations(Es, key_batch_size) :
                        set_key = Multiset(key)
                        queryEs.extend(list(Es_set - set_key))
                        queryIDX.extend([pair_idx] * query_size)
                        keyEs.extend(list(key))
                        keyIDX.extend([pair_idx] * key_batch_size)
                        pair_idx += 1 

                else :  
                    random.shuffle(Es)             
                    for key in combinations(Es, key_batch_size) :
                        set_key = Multiset(key)
                        queryEs.extend(list(Es_set - set_key))
                        queryIDX.extend([pair_idx] * query_size)
                        keyEs.extend(list(key))
                        keyIDX.extend([pair_idx] * key_batch_size)
                        pair_idx += 1 
                        if pair_idx >= hebf_pair_num :
                            break

            self.queryIDX = torch.tensor(queryIDX).to(device)
            self.keyIDX = torch.tensor(keyIDX).to(device)
            self.queryEs = queryEs
            self.keyEs = keyEs

        else:
            self.hebf_use_he_batch = True

            self.total_queryEs = []
            self.total_queryIDX = []
            self.total_keyEs = []
            self.total_keyIDX = []

            self.n_batch = ceil(len(self.totalHE_wto_loops) / hebf_he_batch_size)

            for idx in range(self.n_batch) : 

                t_start , t_end = int(idx * hebf_he_batch_size) , int((idx + 1) * hebf_he_batch_size)

                queryEs = []           
                queryIDX = []       
                keyEs = []             
                keyIDX = []             

                pair_idx = 0            

                totalHE_num = len(self.totalHE_wto_loops)
                random_indices = [random.randrange(0, totalHE_num) for _ in range(totalHE_num)]
                totalHE_wto_loops_random = [self.totalHE_wto_loops[idx] for idx in random_indices]

                for i, he in enumerate(totalHE_wto_loops_random[t_start : t_end]) :

                    Es = he
                    Es_set = Multiset(Es)

                    key_batch_size = floor(len(Es) * hebf_key_batch_ratio)
                    query_size = len(Es) - key_batch_size
                    if key_batch_size < 1:
                        key_batch_size = 1
                        query_size = len(Es) - key_batch_size

                    if query_size < 1:
                        query_size = 1
                        key_batch_size = len(Es) - query_size

                    assert key_batch_size >= 1 and query_size >= 1

                    # calculate the exact possible number of pairs
                    max_pair_num = comb(len(Es), key_batch_size)

                    # generate the key-query pairs
                    if hebf_pair_num > max_pair_num :
                        for key in combinations(Es, key_batch_size) :
                            set_key = Multiset(key)
                            queryEs.extend(list(Es_set - set_key))
                            queryIDX.extend([pair_idx] * query_size)
                            keyEs.extend(list(key))
                            keyIDX.extend([pair_idx] * key_batch_size)
                            pair_idx += 1                     
                    else:
                        random.shuffle(Es)
                        for key in combinations(Es, key_batch_size) :
                            set_key = Multiset(key)
                            queryEs.extend(list(Es_set - set_key))
                            queryIDX.extend([pair_idx] * query_size)
                            keyEs.extend(list(key))
                            keyIDX.extend([pair_idx] * key_batch_size)
                            pair_idx += 1                     
                            if pair_idx >= hebf_pair_num :
                                break

                queryIDX = torch.tensor(queryIDX).to(device)
                keyIDX = torch.tensor(keyIDX).to(device)

                self.total_queryEs.append(queryEs)
                self.total_queryIDX.append(queryIDX)
                self.total_keyEs.append(keyEs)
                self.total_keyIDX.append(keyIDX)

    def hebf_loss_train(self, Z, reduce_method: str='sum'):
        """
        """

        loss = 0

        if self.hebf_use_he_batch : 

            for i in range(len(self.total_queryEs)) : 

                queryEs  : list = self.total_queryEs[i]
                queryIDX : torch.Tensor = self.total_queryIDX[i]
                keyEs  : list = self.total_keyEs[i]
                keyIDX : torch.Tensor = self.total_keyIDX[i]

                indptr = torch._convert_indices_from_coo_to_csr(queryIDX, queryIDX.max().item()+1, out_int32=False)
                aggQuery = segment_csr(Z[queryEs], indptr, reduce=reduce_method)

                aggQuery = F.normalize(self.query_mapper(aggQuery), p=2.0, dim=1, eps=1e-12, out=None)

                indptr = torch._convert_indices_from_coo_to_csr(keyIDX, keyIDX.max().item()+1, out_int32=False)
                aggKey = segment_csr(Z[keyEs], indptr, reduce=reduce_method)

                aggKey = F.normalize(self.key_mapper(aggKey), p=2.0, dim=1, eps=1e-12, out=None)

                loss += self.loss_func(aggQuery, aggKey)


        else : 

            indptr = torch._convert_indices_from_coo_to_csr(self.queryIDX, self.queryIDX.max().item()+1, out_int32=False)
            aggQuery = segment_csr(Z[self.queryEs], indptr, reduce=reduce_method)

            aggQuery = F.normalize(self.query_mapper(aggQuery), p=2.0, dim=1, eps=1e-12, out=None)

            indptr = torch._convert_indices_from_coo_to_csr(self.keyIDX, self.keyIDX.max().item()+1, out_int32=False)
            aggKey = segment_csr(Z[self.keyEs], indptr, reduce=reduce_method)

            aggKey = F.normalize(self.key_mapper(aggKey), p=2.0, dim=1, eps=1e-12, out=None)

            loss += self.loss_func(aggQuery, aggKey)

        return loss

    def generate_key_query_list_val(self, hebf_he_batch_size: int=-1, hebf_key_batch_ratio: float=-1, hebf_pair_num: int=-1, 
                            mylogger: MyLogger=None, device: str='cuda'):
        """
        Prepare the query-key pairs for HEBF loss computation.

        Use `self.totalHE_wto_loops` to avoid the hyperedges that only contain a single edge.
        """

        if hebf_he_batch_size <= 0 :

            self.hebf_use_he_batch = False

            queryEs = []       
            queryIDX = []      
            keyEs = []         
            keyIDX = []        

            pair_idx = 0            

            for i, he in enumerate(self.totalHE_wto_loops) :

                Es = he
                Es_set = Multiset(Es)

                key_batch_size = floor(len(Es) * hebf_key_batch_ratio)
                query_size = len(Es) - key_batch_size
                if key_batch_size < 1:
                    key_batch_size = 1
                    query_size = len(Es) - key_batch_size

                if query_size < 1 :
                    query_size = 1
                    key_batch_size = len(Es) - query_size

                # calculate the exact possible number of pairs
                max_pair_num = comb(len(Es), key_batch_size)

                # generate the key-query pairs
                if hebf_pair_num > max_pair_num :   
                    for key in combinations(Es, key_batch_size) :
                        set_key = Multiset(key)
                        queryEs.extend(list(Es_set - set_key))
                        queryIDX.extend([pair_idx] * query_size)
                        keyEs.extend(list(key))
                        keyIDX.extend([pair_idx] * key_batch_size)
                        pair_idx += 1               

                else :                              
                    random.shuffle(Es)              
                    for key in combinations(Es, key_batch_size) :
                        set_key = Multiset(key)
                        queryEs.extend(list(Es_set - set_key))
                        queryIDX.extend([pair_idx] * query_size)
                        keyEs.extend(list(key))
                        keyIDX.extend([pair_idx] * key_batch_size)
                        pair_idx += 1               
                        if pair_idx >= hebf_pair_num :
                            break

            self.queryIDX_val = torch.tensor(queryIDX).to(device)
            self.keyIDX_val = torch.tensor(keyIDX).to(device)
            self.queryEs_val = queryEs
            self.keyEs_val = keyEs

        else:
            self.hebf_use_he_batch = True

            self.total_queryEs_val = []
            self.total_queryIDX_val = []
            self.total_keyEs_val = []
            self.total_keyIDX_val = []

            self.n_batch = ceil(len(self.totalHE_wto_loops) / hebf_he_batch_size)

            for idx in range(self.n_batch) : 

                t_start , t_end = int(idx * hebf_he_batch_size) , int((idx + 1) * hebf_he_batch_size)

                queryEs = []            
                queryIDX = []           
                keyEs = []              
                keyIDX = []            

                pair_idx = 0            

                totalHE_num = len(self.totalHE_wto_loops)
                random_indices = [random.randrange(0, totalHE_num) for _ in range(totalHE_num)]
                totalHE_wto_loops_random = [self.totalHE_wto_loops[idx] for idx in random_indices]

                for i, he in enumerate(totalHE_wto_loops_random[t_start : t_end]) :

                    Es = he
                    Es_set = Multiset(Es)

                    key_batch_size = floor(len(Es) * hebf_key_batch_ratio)
                    query_size = len(Es) - key_batch_size
                    if key_batch_size < 1:
                        key_batch_size = 1
                        query_size = len(Es) - key_batch_size

                    if query_size < 1:
                        query_size = 1
                        key_batch_size = len(Es) - query_size

                    assert key_batch_size >= 1 and query_size >= 1

                    # calculate the exact possible number of pairs
                    max_pair_num = comb(len(Es), key_batch_size)

                    # generate the key-query pairs
                    if hebf_pair_num > max_pair_num :
                        for key in combinations(Es, key_batch_size) :
                            set_key = Multiset(key)
                            queryEs.extend(list(Es_set - set_key))
                            queryIDX.extend([pair_idx] * query_size)
                            keyEs.extend(list(key))
                            keyIDX.extend([pair_idx] * key_batch_size)
                            pair_idx += 1                      
                    else:
                        random.shuffle(Es)
                        for key in combinations(Es, key_batch_size) :
                            set_key = Multiset(key)
                            queryEs.extend(list(Es_set - set_key))
                            queryIDX.extend([pair_idx] * query_size)
                            keyEs.extend(list(key))
                            keyIDX.extend([pair_idx] * key_batch_size)
                            pair_idx += 1                      
                            if pair_idx >= hebf_pair_num :
                                break

                queryIDX = torch.tensor(queryIDX).to(device)
                keyIDX = torch.tensor(keyIDX).to(device)

                self.total_queryEs_val.append(queryEs)
                self.total_queryIDX_val.append(queryIDX)
                self.total_keyEs_val.append(keyEs)
                self.total_keyIDX_val.append(keyIDX)

    def hebf_pos_sim_val(self, Z, reduce_method: str='sum'):
        """
        """

        sp = []

        if self.hebf_use_he_batch : 

            for i in range(len(self.total_queryEs_val)) : 

                queryEs  : list = self.total_queryEs_val[i]
                queryIDX : torch.Tensor = self.total_queryIDX_val[i]
                keyEs  : list = self.total_keyEs_val[i]
                keyIDX : torch.Tensor = self.total_keyIDX_val[i]

                indptr = torch._convert_indices_from_coo_to_csr(queryIDX, queryIDX.max().item()+1, out_int32=False)
                aggQuery = segment_csr(Z[queryEs], indptr, reduce=reduce_method)

                aggQuery = F.normalize(self.query_mapper(aggQuery), p=2.0, dim=1, eps=1e-12, out=None)

                indptr = torch._convert_indices_from_coo_to_csr(keyIDX, keyIDX.max().item()+1, out_int32=False)
                aggKey = segment_csr(Z[keyEs], indptr, reduce=reduce_method)

                aggKey = F.normalize(self.key_mapper(aggKey), p=2.0, dim=1, eps=1e-12, out=None)

                sp_batch = torch.cosine_similarity(aggQuery, aggKey, dim=1).mean()

                sp.append(sp_batch.item())

        else : 

            indptr = torch._convert_indices_from_coo_to_csr(self.queryIDX_val, self.queryIDX_val.max().item()+1, out_int32=False)
            aggQuery = segment_csr(Z[self.queryEs_val], indptr, reduce=reduce_method)

            aggQuery = F.normalize(self.query_mapper(aggQuery), p=2.0, dim=1, eps=1e-12, out=None)

            indptr = torch._convert_indices_from_coo_to_csr(self.keyIDX_val, self.keyIDX_val.max().item()+1, out_int32=False)
            aggKey = segment_csr(Z[self.keyEs_val], indptr, reduce=reduce_method)

            aggKey = F.normalize(self.key_mapper(aggKey), p=2.0, dim=1, eps=1e-12, out=None)

            sp_batch = torch.cosine_similarity(aggQuery, aggKey, dim=1).mean()
        
        sp = torch.tensor(sp).mean()

        return sp


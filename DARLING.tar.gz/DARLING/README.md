# DARLING: Dual Hypergraph-Enhanced Curriculum-Guided Graph Structure Learning for Node Classification

---

## Environment

- python 3.12
- pytorch 2.4
- pytorch_geometric 2.6.1
- pytorch_scatter 2.1.2
- pytorch_sparse 0.6.18
- dgl 2.4
- NVIDIA GPU 24GB VRAM x1
- RAM 8GB x1

## Notes & Usage

There are **two versions** of the python scripts: `main_tune_darling_ori_alt.py` is for the small datasets, e.g., `Cora`, `Citeseer`, and `main_tune_darling_anc_alt.py` is for the large datasets, e.g., `Pubmed`, `Minesweeper`, `Amazon-ratings`, and `Roman-empire`. The code for the large datasets uses the anchor technique borrowed from [IDGL](https://github.com/hugochan/IDGL) to scale the training process. We also pretrain $f_{HNN}$ by the node-level contrastive learning loss proposed in [TriCL](https://github.com/wooner49/TriCL) to speed up the convergence of $L_{CT}$.

The search space of all the hyperparameters has been added in the code. The example running script is located in [`./scripts`](./scripts) for reference. **One should carefully conduct hyperparameter tuning in your own environment to reproduce the results.**

## Acknowledgements

We borrow some code from these awesome repositories: [OpenGSL](https://github.com/OpenGSL/OpenGSL), [IDGL](https://github.com/hugochan/IDGL).

We also reference the hypergraph-related code from [HypeBoy](https://github.com/kswoo97/hypeboy), [TriCL](https://github.com/wooner49/TriCL), and [UniGNN](https://github.com/OneForward/UniGNN).

**We thank all the authors for their great work!!**

